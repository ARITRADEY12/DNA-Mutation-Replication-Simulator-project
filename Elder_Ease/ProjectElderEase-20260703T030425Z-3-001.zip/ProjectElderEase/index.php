<?php
session_start();

$role = $_SESSION['role'] ?? '';
$dash = 'index.php';
if (!empty($_SESSION['logged_in'])) {
    if ($role === 'admin') $dash = 'dashboard/admin.php';
    elseif ($role === 'caregiver') $dash = 'dashboard/caregiver.php';
    elseif ($role === 'visitor') $dash = 'dashboard/visitor.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222;line-height:1.6}
    .topbar{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff}
    .topbar .wrap{max-width:1100px;margin:0 auto;padding:16px 18px;display:flex;justify-content:space-between;align-items:center}
    .brand{font-weight:800;font-size:20px;letter-spacing:.3px}
    .nav a{color:#fff;text-decoration:none;margin-left:14px;padding:8px 12px;border-radius:10px}
    .nav a:hover{background:rgba(255,255,255,.12)}
    .container{max-width:1100px;margin:28px auto;padding:0 18px}
    .card{background:#fff;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);padding:26px}
    .hero{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;align-items:center}
    @media(max-width:900px){.hero{grid-template-columns:1fr}}
    h1{font-size:34px;margin-bottom:10px}
    p{color:#444}
    .btns{margin-top:14px;display:flex;gap:10px;flex-wrap:wrap}
    .btn{display:inline-block;text-decoration:none;font-weight:700;border-radius:12px;padding:12px 16px}
    .btn-primary{background:#667eea;color:#fff}
    .btn-outline{border:2px solid #667eea;color:#667eea;background:#fff}
    .btn-primary:hover{filter:brightness(.95)}
    .btn-outline:hover{background:#eef1ff}
    .mini{background:#f3f5ff;border-radius:14px;padding:16px;border:1px solid #e6e9ff}
    .grid{margin-top:18px;display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px}
    .feat{background:#fff;border:1px solid #eef0f7;border-radius:14px;padding:16px}
    .footer{max-width:1100px;margin:18px auto 35px;padding:0 18px;color:#666;font-size:14px}
    .badge{display:inline-block;background:#111827;color:#fff;border-radius:999px;padding:6px 10px;font-size:12px;margin-top:8px}
  </style>
</head>
<body>
  <div class="topbar">
    <div class="wrap">
      <div class="brand">ElderEase</div>
      <div class="nav">
        <a href="index.php">Home</a>
        <?php if (!empty($_SESSION['logged_in'])): ?>
          <a href="<?php echo htmlspecialchars($dash); ?>">Dashboard</a>
          <a href="logout.php">Logout</a>
        <?php else: ?>
          <a href="login.php">Login</a>
          <a href="signup_role.php">Signup</a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="card hero">
      <div>
        <h1>ElderEase Senior Care</h1>
        <p>We build a cozy home for our respected seniors</p>

        <?php if (!empty($_SESSION['logged_in'])): ?>
          <div class="badge">
            Logged in as <?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?> (<?php echo htmlspecialchars($role ?: 'user'); ?>)
          </div>
          <div class="btns">
            <a class="btn btn-primary" href="<?php echo htmlspecialchars($dash); ?>">Go to Dashboard</a>
            <a class="btn btn-outline" href="logout.php">Logout</a>
          </div>
        <?php else: ?>
          <div class="btns">
            <a class="btn btn-primary" href="signup_role.php">Create Account</a>
            <a class="btn btn-outline" href="login.php">Login</a>
          </div>
        <?php endif; ?>
      </div>

    </div>

    <div class="grid">
      <div class="feat"><strong>Admin</strong></div>
      <div class="feat"><strong>Caregiver</strong></div>
      <div class="feat"><strong>Visitor</strong></div>
    </div>
  </div>

  <div class="footer">© <?php echo date('Y'); ?> ElderEase</div>
</body>
</html>


