<?php
session_start();
require_once __DIR__ . "/../connection.php";

// Check access
$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['admin', 'caregiver', 'visitor'])) {
    die("Access denied");
}

$res_id = (int)($_GET['resident_id'] ?? 0);
if ($res_id <= 0) {
    die("Invalid resident ID");
}

// Get resident info
$res_stmt = $conn->prepare("SELECT Name FROM Resident WHERE ID = ?");
$res_stmt->bind_param("i", $res_id);
$res_stmt->execute();
$resident = $res_stmt->get_result()->fetch_assoc();

if (!$resident) {
    die("Resident not found");
}

// Get medical records
$records_stmt = $conn->prepare("
    SELECT * FROM Medical_Record 
    WHERE R_ID = ? 
    ORDER BY Checkup_Date DESC
");
$records_stmt->bind_param("i", $res_id);
$records_stmt->execute();
$records = $records_stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Medical Records</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background: #f5f5f5; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; }
        h2 { color: #333; margin-bottom: 10px; }
        .header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 20px; 
            background: white; 
            padding: 15px; 
            border-radius: 8px; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .resident-info { color: #666; }
        .btn { 
            background: #28a745; 
            color: white; 
            padding: 8px 15px; 
            border-radius: 4px; 
            text-decoration: none; 
            display: inline-block;
        }
        .btn:hover { background: #218838; }
        .record-card { 
            background: white; 
            padding: 15px; 
            margin-bottom: 15px; 
            border-radius: 8px; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .record-date { 
            color: #007bff; 
            font-weight: bold; 
            margin-bottom: 10px;
        }
        .record-content { margin-top: 10px; }
        .record-content p { margin: 5px 0; color: #555; }
        .no-records { 
            background: white; 
            padding: 30px; 
            text-align: center; 
            border-radius: 8px; 
            color: #666;
        }
        .back-link { 
            display: inline-block; 
            margin-top: 15px; 
            color: #007bff; 
            text-decoration: none;
        }
        strong { color: #333; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h2>Medical Records</h2>
                <div class="resident-info">
                    <strong>Resident:</strong> <?php echo htmlspecialchars($resident['Name']); ?> (ID: <?php echo $res_id; ?>)
                </div>
            </div>
            
            <?php if (in_array($role, ['admin', 'caregiver'])): ?>
                <a href="add_medical_record.php?resident_id=<?php echo $res_id; ?>" class="btn">
                    + Add New Record
                </a>
            <?php endif; ?>
        </div>
        
        <?php if ($records->num_rows === 0): ?>
            <div class="no-records">
                <h3>No medical records found</h3>
                <p>No medical records have been added for this resident yet.</p>
            </div>
        <?php else: ?>
            <?php while ($record = $records->fetch_assoc()): ?>
                <div class="record-card">
                    <div class="record-date">
                        Checkup Date: <?php echo $record['Checkup_Date']; ?>
                    </div>
                    
                    <div class="record-content">
                        <p><strong>Diagnosis:</strong> <?php echo htmlspecialchars($record['Diagnosis']); ?></p>
                        
                        <?php if (!empty($record['Prescription'])): ?>
                            <p><strong>Prescription:</strong> <?php echo htmlspecialchars($record['Prescription']); ?></p>
                        <?php endif; ?>
                        
                        <?php if (!empty($record['Notes'])): ?>
                            <p><strong>Notes:</strong> <?php echo htmlspecialchars($record['Notes']); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
        
        <!-- FIXED LINK: Goes back to resident profile -->
        <a href="../residents/resident_profile.php?id=<?php echo $res_id; ?>" class="back-link">
            ← Back to Resident Profile
        </a>
    </div>
</body>
</html>