<?php
session_start();
require_once __DIR__ . "/../connection.php";

// Check access
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'caregiver'])) {
    die("Access denied");
}

$res_id = (int)($_GET['resident_id'] ?? 0);
if ($res_id <= 0) {
    die("Invalid resident ID");
}

// Get resident name for display
$res_stmt = $conn->prepare("SELECT Name FROM Resident WHERE ID = ?");
$res_stmt->bind_param("i", $res_id);
$res_stmt->execute();
$resident = $res_stmt->get_result()->fetch_assoc();

if (!$resident) {
    die("Resident not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $diagnosis = trim($_POST['diagnosis'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $prescription = trim($_POST['prescription'] ?? '');
    $checkup_date = $_POST['checkup_date'] ?? '';
    
    if (empty($diagnosis) || empty($checkup_date)) {
        $error = "Diagnosis and date are required.";
    } else {
        $stmt = $conn->prepare("
            INSERT INTO Medical_Record (Diagnosis, Notes, Prescription, Checkup_Date, R_ID)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "ssssi",
            $diagnosis,
            $notes,
            $prescription,
            $checkup_date,
            $res_id
        );
        
        if ($stmt->execute()) {
            $success = "Medical record added successfully!";
            // Clear form
            $_POST['diagnosis'] = $_POST['notes'] = $_POST['prescription'] = '';
        } else {
            $error = "Failed to add record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Medical Record</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background: #f5f5f5; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h2 { color: #333; margin-bottom: 10px; }
        .resident-info { background: #e9f7fe; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
        .alert { padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        label { display: block; margin: 10px 0 5px; font-weight: bold; color: #555; }
        input, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        textarea { min-height: 80px; }
        button { background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; margin-top: 10px; }
        button:hover { background: #0056b3; }
        .back-link { display: inline-block; margin-top: 15px; color: #007bff; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Medical Record</h2>
        
        <div class="resident-info">
            <strong>Resident:</strong> <?php echo htmlspecialchars($resident['Name']); ?> (ID: <?php echo $res_id; ?>)
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="post">
            <label for="diagnosis">Diagnosis *</label>
            <textarea id="diagnosis" name="diagnosis" required><?php echo htmlspecialchars($_POST['diagnosis'] ?? ''); ?></textarea>
            
            <label for="notes">Notes</label>
            <textarea id="notes" name="notes"><?php echo htmlspecialchars($_POST['notes'] ?? ''); ?></textarea>
            
            <label for="prescription">Prescription</label>
            <textarea id="prescription" name="prescription"><?php echo htmlspecialchars($_POST['prescription'] ?? ''); ?></textarea>
            
            <label for="checkup_date">Checkup Date *</label>
            <input type="date" id="checkup_date" name="checkup_date" required 
                   value="<?php echo htmlspecialchars($_POST['checkup_date'] ?? date('Y-m-d')); ?>">
            
            <button type="submit">Save Medical Record</button>
        </form>
        
        <a href="view_medical_records.php?resident_id=<?php echo $res_id; ?>" class="back-link">
            ← Back to Medical Records
        </a>
    </div>
</body>
</html>