<?php
session_start();
require_once __DIR__ . "/../connection.php";

// Add this at the top of decision.php, after the session_start()
if (!in_array($_SESSION['role'] ?? '', ['admin','caregiver'], true)) {
    die("Access denied");
}

// Check if new columns exist, if not add them dynamically
$check_columns = $conn->query("SHOW COLUMNS FROM Appointment LIKE 'Visit_Outcome'");
if ($check_columns->num_rows === 0) {
    // Add missing columns
    $conn->query("ALTER TABLE Appointment ADD COLUMN Visit_Outcome TEXT NULL AFTER Decline_Reason");
    $conn->query("ALTER TABLE Appointment ADD COLUMN Completed_At TIMESTAMP NULL AFTER Created_At");
    $conn->query("ALTER TABLE Appointment MODIFY Status ENUM('Pending','Approved','Declined','Completed','Missed') DEFAULT 'Pending'");
}

if (!in_array($_SESSION['role'] ?? '', ['admin','caregiver'], true)) {
    die("Access denied");
}

$id = (int)($_POST['id'] ?? 0);
$action = $_POST['action'] ?? '';
$reason = trim($_POST['reason'] ?? '');

if ($id <= 0) die("Invalid request");

if ($action === 'approve') {
    $stmt = $conn->prepare("
        UPDATE Appointment
        SET Status='Approved', Decision_By=?
        WHERE ID=?
    ");
    $stmt->bind_param("si", $_SESSION['role'], $id);
    $stmt->execute();
}
elseif ($action === 'decline') {
    if ($reason === '') die("Decline reason required");

    $stmt = $conn->prepare("
        UPDATE Appointment
        SET Status='Declined', Decision_By=?, Decline_Reason=?
        WHERE ID=?
    ");
    $stmt->bind_param("ssi", $_SESSION['role'], $reason, $id);
    $stmt->execute();
}
// ADDED: Handle completion/missing of appointments
elseif (in_array($action, ['complete', 'missed'], true)) {
    $outcome = trim($_POST['outcome'] ?? '');
    $new_status = ucfirst($action); // 'complete' -> 'Completed', 'missed' -> 'Missed'
    
    $stmt = $conn->prepare("
        UPDATE Appointment
        SET Status=?, Visit_Outcome=?, Completed_At=NOW()
        WHERE ID=? AND Status='Approved'
    ");
    $stmt->bind_param("ssi", $new_status, $outcome, $id);
    $stmt->execute();
}

header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
?>