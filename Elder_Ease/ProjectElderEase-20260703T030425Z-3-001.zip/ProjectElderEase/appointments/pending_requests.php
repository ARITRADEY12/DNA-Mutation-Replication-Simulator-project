<?php
require_once __DIR__ . "/../connection.php";

$role = $_SESSION['role'] ?? '';
$user_id = (int)$_SESSION['user_id'];

$sql = "
SELECT a.*, v.Name AS visitor_name, r.Name AS resident_name
FROM Appointment a
JOIN Visitor v ON a.Visitor_ID = v.V_ID
JOIN Resident r ON a.Resident_ID = r.ID
WHERE a.Status = 'Pending'
";

if ($role === 'caregiver') {
    $sql .= " AND a.Resident_ID IN (
        SELECT Res_ID FROM cares WHERE Cr_ID = ?
    )";
}

$stmt = $conn->prepare($sql);

if ($role === 'caregiver') {
    $stmt->bind_param("i", $user_id);
}

$stmt->execute();
$requests = $stmt->get_result();
?>
<div class="card">
<h3>Appointment Requests</h3>

<?php if ($requests->num_rows === 0): ?>
    <p>No pending requests.</p>
<?php else: ?>
    <?php while ($r = $requests->fetch_assoc()): ?>
        <div style="border:1px solid #ccc;padding:10px;margin-bottom:8px">
            <strong>Visitor:</strong> <?=htmlspecialchars($r['visitor_name'])?><br>
            <strong>Resident:</strong> <?=htmlspecialchars($r['resident_name'])?><br>
            <strong>Date:</strong> <?=$r['Requested_Date']?> <?=$r['Requested_Time']?><br>

            <form method="post" action="../appointments/decision.php" style="margin-top:6px">
                <input type="hidden" name="id" value="<?=$r['ID']?>">
                <button name="action" value="approve">Approve</button>
                <button name="action" value="decline">Decline</button><br>
                <textarea name="reason" placeholder="Reason if declined"></textarea>
            </form>
        </div>
    <?php endwhile; ?>
<?php endif; ?>
</div>
