<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in']) || ($_SESSION['role'] ?? '') !== 'visitor') {
    header("Location: ../login.php");
    exit();
}

$visitor_id = (int)$_SESSION['user_id'];
$err = '';
$selected_date = '';
$selected_time = '';
$resident_ids = [];

// GET ALL RESIDENTS (not just those in visits table)
$all_residents = [];
$res_stmt = $conn->prepare("
    SELECT ID, Name 
    FROM Resident
    ORDER BY Name
");
$res_stmt->execute();
$result = $res_stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $all_residents[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $resident_ids = $_POST['resident_ids'] ?? [];
    $selected_date = $_POST['date'] ?? '';
    $selected_time = $_POST['time'] ?? '';

    if (empty($resident_ids) || $selected_date === '' || $selected_time === '') {
        $err = "At least one resident, date and time are required.";
    } else {
        // Validate date is not in the past
        if (strtotime($selected_date . ' ' . $selected_time) < time()) {
            $err = "Cannot schedule appointments in the past.";
        } else {
            $conflicts = [];
            $success_count = 0;
            $errors = [];
            
            // Check each selected resident for time conflicts
            foreach ($resident_ids as $resident_id) {
                $resident_id = (int)$resident_id;
                
                if ($resident_id <= 0) continue;
                
                // Check if resident exists
                $chk = $conn->prepare("SELECT ID FROM Resident WHERE ID = ?");
                $chk->bind_param("i", $resident_id);
                $chk->execute();
                $chk->store_result();
                
                if ($chk->num_rows === 0) {
                    $errors[] = "Invalid Resident ID: $resident_id";
                    continue;
                }
                
                // Check for time conflicts (pending or approved appointments at same date/time)
                $conflict_check = $conn->prepare("
                    SELECT ID FROM Appointment
                    WHERE Resident_ID = ? 
                    AND Requested_Date = ?
                    AND Requested_Time = ?
                    AND Status IN ('Pending', 'Approved')
                ");
                $conflict_check->bind_param("iss", $resident_id, $selected_date, $selected_time);
                $conflict_check->execute();
                $conflict_check->store_result();
                
                if ($conflict_check->num_rows > 0) {
                    // Get resident name for error message
                    $name_stmt = $conn->prepare("SELECT Name FROM Resident WHERE ID = ?");
                    $name_stmt->bind_param("i", $resident_id);
                    $name_stmt->execute();
                    $name_result = $name_stmt->get_result();
                    $resident_name = $name_result->fetch_assoc()['Name'] ?? 'Unknown';
                    
                    $conflicts[] = $resident_name;
                    continue;
                }
                
                // Prevent duplicate pending request for same visitor+resident+date
                $dup = $conn->prepare("
                    SELECT ID FROM Appointment
                    WHERE Visitor_ID = ? AND Resident_ID = ? 
                    AND Status = 'Pending' AND Requested_Date = ?
                ");
                $dup->bind_param("iis", $visitor_id, $resident_id, $selected_date);
                $dup->execute();
                $dup->store_result();
                
                if ($dup->num_rows > 0) {
                    $errors[] = "You already have a pending request for this resident on $selected_date";
                    continue;
                }
                
                // Insert appointment
                $stmt = $conn->prepare("
                    INSERT INTO Appointment
                    (Visitor_ID, Resident_ID, Requested_Date, Requested_Time, Status)
                    VALUES (?, ?, ?, ?, 'Pending')
                ");
                $stmt->bind_param("iiss", $visitor_id, $resident_id, $selected_date, $selected_time);
                
                if ($stmt->execute()) {
                    $success_count++;
                } else {
                    $errors[] = "Failed to create appointment for resident ID: $resident_id";
                }
            }
            
            if (!empty($conflicts)) {
                $err = "The following residents already have appointments at $selected_time on $selected_date:<br>" . 
                       implode("<br>", array_map(function($name) {
                           return "• " . htmlspecialchars($name);
                       }, $conflicts)) . 
                       "<br><br>Please select a different time or date.";
                // Keep form data filled so user can adjust
                $resident_ids = $_POST['resident_ids'] ?? [];
            } elseif ($success_count > 0) {
                $_SESSION['flash_success'] = "Appointment request submitted for $success_count resident(s).";
                header("Location: ../dashboard/visitor.php");
                exit();
            } elseif (!empty($errors)) {
                $err = implode("<br>", $errors);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Request Appointment</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .appointment-container {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }
        
        h2 {
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #3498db;
        }
        
        .error-message {
            background-color: #ffeaea;
            color: #c0392b;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #c0392b;
        }
        
        .conflict-message {
            background-color: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #ffc107;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #34495e;
            font-size: 15px;
        }
        
        .resident-selection {
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            padding: 15px;
            background-color: #f9f9f9;
        }
        
        .resident-list {
            max-height: 300px;
            overflow-y: auto;
            margin-top: 10px;
            padding: 10px;
            background: white;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        
        .resident-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
            transition: background-color 0.2s;
        }
        
        .resident-item:last-child {
            border-bottom: none;
        }
        
        .resident-item:hover {
            background-color: #f0f8ff;
        }
        
        .resident-item input[type="checkbox"] {
            margin-right: 12px;
            transform: scale(1.2);
        }
        
        .resident-item label {
            display: inline;
            font-weight: normal;
            cursor: pointer;
            font-size: 15px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 15px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        
        .form-row {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .btn {
            flex: 1;
            padding: 14px 20px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
        }
        
        .btn-primary {
            background-color: #3498db;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(41, 128, 185, 0.2);
        }
        
        .btn-secondary {
            background-color: #95a5a6;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #7f8c8d;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(127, 140, 141, 0.2);
        }
        
        .no-residents {
            background-color: #fff8e1;
            border: 1px solid #ffd54f;
            border-radius: 6px;
            padding: 20px;
            text-align: center;
            color: #f57c00;
        }
        
        .info-note {
            background-color: #e8f4fc;
            border-left: 4px solid #3498db;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            font-size: 14px;
            color: #2c3e50;
        }
        
        .select-all {
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 1px solid #ddd;
        }
        
        .select-all label {
            font-weight: 600;
            cursor: pointer;
        }
        
        .select-all input[type="checkbox"] {
            margin-right: 8px;
            transform: scale(1.1);
        }
    </style>
</head>
<body>
    <div class="appointment-container">
        <h2>Request Appointment</h2>
        
        <?php if ($err): ?>
            <div class="<?= strpos($err, 'already have appointments') !== false ? 'conflict-message' : 'error-message' ?>">
                <?= $err ?>
            </div>
        <?php endif; ?>
        
        <form method="post" id="appointmentForm">
            <div class="form-group">
                <label>Select Residents (can select multiple)</label>
                
                <?php if (empty($all_residents)): ?>
                    <div class="no-residents">
                        <p>No residents found in the system. Contact admin.</p>
                        <a href="../dashboard/visitor.php" class="btn btn-secondary" style="max-width: 200px; margin: 0 auto;">Return to Dashboard</a>
                    </div>
                <?php else: ?>
                    <div class="info-note">
                        Select one or more residents. If a resident already has an appointment at your chosen time, you'll be asked to select a different time.
                    </div>
                    <div class="resident-selection">
                        <div class="select-all">
                            <input type="checkbox" id="selectAllResidents">
                            <label for="selectAllResidents">Select All Residents</label>
                        </div>
                        <div class="resident-list">
                            <?php foreach ($all_residents as $resident): ?>
                                <div class="resident-item">
                                    <input type="checkbox" name="resident_ids[]" 
                                           value="<?= $resident['ID'] ?>" 
                                           id="res_<?= $resident['ID'] ?>"
                                           <?= in_array($resident['ID'], $resident_ids) ? 'checked' : '' ?>>
                                    <label for="res_<?= $resident['ID'] ?>">
                                        <?= htmlspecialchars($resident['Name']) ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($all_residents)): ?>
                <div class="form-row">
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" id="date" name="date" class="form-control" 
                               value="<?= htmlspecialchars($selected_date) ?>"
                               required min="<?= date('Y-m-d') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="time">Time</label>
                        <input type="time" id="time" name="time" class="form-control" 
                               value="<?= htmlspecialchars($selected_time) ?>"
                               required min="08:00" max="20:00" step="1800">
                        <small style="color: #666; margin-top: 5px; display: block;">
                            Select time between 8:00 AM and 8:00 PM (30-minute intervals)
                        </small>
                    </div>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn btn-primary">Request Appointment</button>
                    <button type="button" class="btn btn-secondary" onclick="clearForm()">Clear Form</button>
                    <a href="../dashboard/visitor.php" class="btn btn-secondary">Cancel</a>
                </div>
            <?php endif; ?>
        </form>
    </div>

    <script>
        // Set minimum time to current time if date is today
        document.getElementById('date').addEventListener('change', function() {
            const dateInput = this;
            const timeInput = document.getElementById('time');
            const today = new Date().toISOString().split('T')[0];
            
            if (dateInput.value === today) {
                const now = new Date();
                // Round up to next 30 minutes
                const currentHour = now.getHours();
                const currentMinute = now.getMinutes();
                let nextHour = currentHour;
                let nextMinute = Math.ceil(currentMinute / 30) * 30;
                
                if (nextMinute >= 60) {
                    nextHour++;
                    nextMinute = 0;
                }
                
                timeInput.min = `${nextHour.toString().padStart(2, '0')}:${nextMinute.toString().padStart(2, '0')}`;
            } else {
                timeInput.min = "08:00";
            }
        });
        
        // Initialize min time on page load
        document.addEventListener('DOMContentLoaded', function() {
            const dateInput = document.getElementById('date');
            const today = new Date().toISOString().split('T')[0];
            if (dateInput.value === today) {
                const now = new Date();
                const currentHour = now.getHours().toString().padStart(2, '0');
                const currentMinute = now.getMinutes().toString().padStart(2, '0');
                document.getElementById('time').min = `${currentHour}:${currentMinute}`;
            }
        });
        
        // Select All functionality
        document.getElementById('selectAllResidents').addEventListener('change', function(e) {
            const checkboxes = document.querySelectorAll('input[name="resident_ids[]"]');
            checkboxes.forEach(cb => cb.checked = e.target.checked);
        });
        
        // Clear form function
        function clearForm() {
            document.getElementById('appointmentForm').reset();
            document.getElementById('date').value = '';
            document.getElementById('time').value = '';
            document.getElementById('selectAllResidents').checked = false;
            
            // Uncheck all resident checkboxes
            const checkboxes = document.querySelectorAll('input[name="resident_ids[]"]');
            checkboxes.forEach(cb => cb.checked = false);
        }
    </script>
</body>
</html>