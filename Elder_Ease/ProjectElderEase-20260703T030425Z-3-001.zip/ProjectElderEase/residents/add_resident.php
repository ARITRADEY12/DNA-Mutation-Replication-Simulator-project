<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit();
}
$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['admin','caregiver'], true)) {
    $_SESSION['error'] = "Access denied.";
    header("Location: ../login.php");
    exit();
}

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $age = ($_POST['age'] === '' ? null : (int)$_POST['age']);
    $gender = $_POST['gender'] ?? 'Other';
    $health = trim($_POST['health'] ?? '');
    $height = ($_POST['height'] === '' ? null : (float)$_POST['height']);
    $weight = ($_POST['weight'] === '' ? null : (float)$_POST['weight']);
    $room = trim($_POST['room'] ?? '');

    if ($name === '') {
        $err = "Resident name is required.";
    } else {
        try {
            // If room empty, store NULL
            $room_val = ($room === '') ? null : $room;

            $stmt = $conn->prepare("
                INSERT INTO Resident (Name, Age, Gender, Health_Status, Height, Weight, R_Room_Number)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                "sissdds",
                $name,
                $age,
                $gender,
                $health,
                $height,
                $weight,
                $room_val
            );
            $stmt->execute();

            $resident_id = (int)$conn->insert_id;

            // If caregiver is adding, auto-assign in cares (safe prepared)
            if ($role === 'caregiver') {
                $care_id = (int)$_SESSION['user_id'];

                // Prevent duplicate assignment row
                $chk = $conn->prepare("SELECT 1 FROM cares WHERE Cr_ID=? AND Res_ID=? LIMIT 1");
                $chk->bind_param("ii", $care_id, $resident_id);
                $chk->execute();

                if ($chk->get_result()->num_rows === 0) {
                    $ins = $conn->prepare("INSERT INTO cares (Cr_ID, Res_ID) VALUES (?, ?)");
                    $ins->bind_param("ii", $care_id, $resident_id);
                    $ins->execute();
                }
            }

            $_SESSION['flash_success'] = "Resident registered successfully.";
            header("Location: resident_profile.php?id=" . $resident_id);
            exit();

        } catch (mysqli_sql_exception $e) {
            $err = "Failed to add resident: " . $e->getMessage();
        }
    }
}

// Rooms (optional)
$rooms = [];
try {
    $r = $conn->query("SELECT Room_Number FROM Room WHERE Status='Vacant' ORDER BY Room_Number");
    while ($row = $r->fetch_assoc()) $rooms[] = $row['Room_Number'];
} catch (Exception $e) {
    // Room table might be empty; ignore safely
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Add Resident - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222}
    .top{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff}
    .wrap{max-width:980px;margin:0 auto;padding:16px 18px;display:flex;justify-content:space-between;align-items:center}
    a{color:#fff;text-decoration:none;font-weight:900}
    .container{max-width:980px;margin:18px auto;padding:0 18px}
    .card{background:#fff;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);padding:18px;border:1px solid #eef0f7}
    h1{font-size:22px;margin-bottom:6px}
    .sub{color:#666;margin-bottom:14px}
    .msg{padding:12px;border-radius:12px;margin-bottom:14px;border:1px solid}
    .err{background:#ffe9ea;border-color:#ffb2b7;color:#7a1020;font-weight:800}
    label{display:block;font-weight:900;margin:12px 0 6px}
    input,select{width:100%;padding:12px;border-radius:12px;border:2px solid #e7e7ef;font-size:15px}
    input:focus,select:focus{outline:none;border-color:#667eea;box-shadow:0 0 0 3px rgba(102,126,234,.12)}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    @media(max-width:700px){.row{grid-template-columns:1fr}}
    .btn{margin-top:14px;width:100%;border:none;border-radius:12px;padding:12px;font-weight:1000;background:#667eea;color:#fff;cursor:pointer}
    .btn:hover{filter:brightness(.96)}
    .links{margin-top:12px;display:flex;gap:10px;flex-wrap:wrap}
    .linkbtn{display:inline-block;background:#111827;color:#fff;border-radius:12px;padding:10px 12px;text-decoration:none;font-weight:900}
    .linkbtn:hover{filter:brightness(.95)}
  </style>
</head>
<body>
  <div class="top">
    <div class="wrap">
      <div style="font-weight:1000">Add Resident</div>
      <div>
        <a href="<?php echo ($role==='admin') ? '../dashboard/admin.php' : '../dashboard/caregiver.php'; ?>">Dashboard</a>
        &nbsp; | &nbsp;
        <a href="../logout.php">Logout</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="card">
      <h1>Resident Registration</h1>
      <div class="sub">After saving, you will be redirected to the resident profile page.</div>

      <?php if ($err): ?>
        <div class="msg err"><?php echo htmlspecialchars($err); ?></div>
      <?php endif; ?>

      <form method="post">
        <label for="name">Resident Name</label>
        <input id="name" name="name" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" placeholder="Full name">

        <div class="row">
          <div>
            <label for="age">Age</label>
            <input id="age" name="age" type="number" min="0" value="<?php echo htmlspecialchars($_POST['age'] ?? ''); ?>" placeholder="Optional">
          </div>
          <div>
            <label for="gender">Gender</label>
            <select id="gender" name="gender">
              <?php
                $g = $_POST['gender'] ?? 'Other';
                $opts = ['Male','Female','Other'];
                foreach ($opts as $o) {
                    $sel = ($g === $o) ? 'selected' : '';
                    echo "<option value=\"{$o}\" {$sel}>{$o}</option>";
                }
              ?>
            </select>
          </div>
        </div>

        <label for="health">Health Status</label>
        <input id="health" name="health" value="<?php echo htmlspecialchars($_POST['health'] ?? ''); ?>" placeholder="e.g., Stable / Needs monitoring">

        <div class="row">
          <div>
            <label for="height">Height (cm)</label>
            <input id="height" name="height" type="number" step="0.01" value="<?php echo htmlspecialchars($_POST['height'] ?? ''); ?>" placeholder="Optional">
          </div>
          <div>
            <label for="weight">Weight (kg)</label>
            <input id="weight" name="weight" type="number" step="0.01" value="<?php echo htmlspecialchars($_POST['weight'] ?? ''); ?>" placeholder="Optional">
          </div>
        </div>

        <label for="room">Room (optional)</label>
        <?php if (!empty($rooms)): ?>
          <select id="room" name="room">
            <option value="">-- No room --</option>
            <?php
              $selRoom = $_POST['room'] ?? '';
              foreach ($rooms as $rn) {
                  $sel = ($selRoom === $rn) ? 'selected' : '';
                  echo "<option value=\"" . htmlspecialchars($rn) . "\" {$sel}>" . htmlspecialchars($rn) . "</option>";
              }
            ?>
          </select>
        <?php else: ?>
          <input id="room" name="room" value="<?php echo htmlspecialchars($_POST['room'] ?? ''); ?>" placeholder="Type room number (if any)">
        <?php endif; ?>

        <button class="btn" type="submit">Save Resident</button>
      </form>

      <div class="links">
        <?php if ($role === 'admin'): ?>
          <a class="linkbtn" href="assign_resident.php">Assign Resident</a>
        <?php else: ?>
          <a class="linkbtn" href="my_residents.php">My Residents</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>
