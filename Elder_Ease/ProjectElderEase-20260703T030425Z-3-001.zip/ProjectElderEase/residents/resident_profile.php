<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit();
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['admin','caregiver','visitor'], true)) {
    $_SESSION['error'] = "Access denied.";
    header("Location: ../login.php");
    exit();
}

// Accept both ?id= and legacy ?ID=
$res_id = 0;
if (isset($_GET['id'])) $res_id = (int)$_GET['id'];
elseif (isset($_GET['ID'])) $res_id = (int)$_GET['ID'];

if ($res_id <= 0) {
    $_SESSION['error'] = "Invalid resident ID.";
    header("Location: " . ($role === 'admin' ? "../dashboard/admin.php" : "../dashboard/caregiver.php"));
    exit();
}

// Caregiver can view only if assigned
if ($role === 'caregiver') {
    $care_id = (int)$_SESSION['user_id'];
    $chk = $conn->prepare("SELECT 1 FROM cares WHERE Cr_ID=? AND Res_ID=? LIMIT 1");
    $chk->bind_param("ii", $care_id, $res_id);
    $chk->execute();
    if ($chk->get_result()->num_rows === 0) {
        $_SESSION['error'] = "Access denied: resident not assigned to you.";
        header("Location: my_residents.php");
        exit();
    }
}

// Visitor: allow view only if in visits mapping
if ($role === 'visitor') {
    $vis_id = (int)$_SESSION['user_id'];
    $chk = $conn->prepare("SELECT 1 FROM visits WHERE Vis_ID=? AND Res_ID=? LIMIT 1");
    $chk->bind_param("ii", $vis_id, $res_id);
    $chk->execute();
    if ($chk->get_result()->num_rows === 0) {
        $_SESSION['error'] = "Access denied: you do not have access to this resident.";
        header("Location: ../dashboard/visitor.php");
        exit();
    }
}

$stmt = $conn->prepare("
    SELECT ID AS id, Name AS name, Age AS age, Gender AS gender, Health_Status AS health, Height AS height, Weight AS weight, R_Room_Number AS room
    FROM Resident
    WHERE ID = ?
    LIMIT 1
");
$stmt->bind_param("i", $res_id);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();

if (!$resident) {
    $_SESSION['error'] = "Resident not found.";
    header("Location: " . ($role === 'admin' ? "../dashboard/admin.php" : "../dashboard/caregiver.php"));
    exit();
}

$flash = $_SESSION['flash_success'] ?? '';
unset($_SESSION['flash_success']);

$back = "../dashboard/admin.php";
if ($role === 'caregiver') $back = "my_residents.php";
if ($role === 'visitor') $back = "../dashboard/visitor.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Resident Profile - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222}
    .top{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff}
    .wrap{max-width:980px;margin:0 auto;padding:16px 18px;display:flex;justify-content:space-between;align-items:center}
    a{color:#fff;text-decoration:none;font-weight:900}
    .container{max-width:980px;margin:18px auto;padding:0 18px}
    .card{background:#fff;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);padding:18px;border:1px solid #eef0f7}
    h1{font-size:22px;margin-bottom:6px}
    .sub{color:#666;margin-bottom:12px}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:10px}
    .k{color:#666;font-weight:900;font-size:12px;text-transform:uppercase;letter-spacing:.8px}
    .v{margin-top:6px;font-weight:800}
    .msg{margin-bottom:12px;background:#e9fff1;border:1px solid #b7f0c7;color:#0f5132;padding:12px;border-radius:14px;font-weight:700}
    .btn{display:inline-block;margin-top:12px;background:#111827;color:#fff;text-decoration:none;font-weight:1000;padding:10px 12px;border-radius:12px}
    .btn:hover{filter:brightness(.95)}
  </style>
</head>
<body>
  <div class="top">
    <div class="wrap">
      <div style="font-weight:1000">Resident Profile</div>
      <div>
        <a href="<?php echo htmlspecialchars($back); ?>">Back</a>
        &nbsp; | &nbsp;
        <a href="../logout.php">Logout</a>
      </div>
    </div>
  </div>

  <div class="container">
    <?php if ($flash): ?>
      <div class="msg"><?php echo htmlspecialchars($flash); ?></div>
    <?php endif; ?>

    <div class="card">
      <h1><?php echo htmlspecialchars($resident['name']); ?></h1>
      <div class="sub">Resident ID: <?php echo (int)$resident['id']; ?></div>

      <div class="grid">
        <div><div class="k">Age</div><div class="v"><?php echo htmlspecialchars($resident['age'] ?? 'N/A'); ?></div></div>
        <div><div class="k">Gender</div><div class="v"><?php echo htmlspecialchars($resident['gender'] ?? 'N/A'); ?></div></div>
        <div><div class="k">Room</div><div class="v"><?php echo htmlspecialchars($resident['room'] ?? 'N/A'); ?></div></div>
        <div><div class="k">Health Status</div><div class="v"><?php echo htmlspecialchars($resident['health'] ?? 'N/A'); ?></div></div>
        <div><div class="k">Height</div><div class="v"><?php echo htmlspecialchars($resident['height'] ?? 'N/A'); ?></div></div>
        <div><div class="k">Weight</div><div class="v"><?php echo htmlspecialchars($resident['weight'] ?? 'N/A'); ?></div></div>
      </div>
	  <?php if (($_SESSION['role'] ?? '') === 'visitor'): ?>
		  <a href="../appointments/request_appointment.php?resident_id=<?php echo (int)$resident['ID']; ?>">
			  Request Appointment
		  </a>
	  <?php endif; ?>
      <?php if ($role !== 'visitor'): ?>
        <a class="btn" href="add_resident.php">Add Another Resident</a>
      <?php endif; ?>
	  <?php
		$apps = $conn->prepare("
			SELECT a.*, v.Name AS visitor
			FROM Appointment a
			JOIN Visitor v ON a.Visitor_ID=v.V_ID
			WHERE a.Resident_ID=? AND a.Status='Approved'
		");
		$apps->bind_param("i", $resident['ID']);
		$apps->execute();
		$res = $apps->get_result();?>
		<h3>Appointments</h3>
		<?php while($a=$res->fetch_assoc()): ?>
		<p>
		<?=htmlspecialchars($a['visitor'])?> — <?=$a['Requested_Date']?> <?=$a['Requested_Time']?>
		</p>
	  <?php endwhile; ?>
    </div>
	<?php
	// Only show past appointment management to caregivers/admins
	if (in_array($role, ['caregiver', 'admin'], true)):
		// PAST APPOINTMENTS (Approved and date has passed)
		$past_stmt = $conn->prepare("
			SELECT a.*, v.Name AS visitor_name
			FROM Appointment a
			JOIN Visitor v ON a.Visitor_ID = v.V_ID
			WHERE a.Resident_ID = ? 
			AND a.Status = 'Approved'
			AND (a.Requested_Date < CURDATE() OR (a.Requested_Date = CURDATE() AND a.Requested_Time < CURTIME()))
			ORDER BY a.Requested_Date DESC, a.Requested_Time DESC
		");
		$past_stmt->bind_param("i", $resident['id']);
		$past_stmt->execute();
		$past_apps = $past_stmt->get_result();
	?>

	<div class="card">
		<h3>Past Appointments (Needs Action)</h3>
		<?php if ($past_apps->num_rows === 0): ?>
			<p>No past appointments requiring action.</p>
		<?php else: ?>
			<?php while($app = $past_apps->fetch_assoc()): ?>
				<div style="border:1px solid #ffc107; padding:10px; margin-bottom:10px; border-radius:5px; background:#fff8e1;">
					<strong>Visitor:</strong> <?= htmlspecialchars($app['visitor_name']) ?><br>
					<strong>Date:</strong> <?= $app['Requested_Date'] ?> <strong>Time:</strong> <?= $app['Requested_Time'] ?><br>
					
					<form method="post" action="../appointments/decision.php" style="margin-top:8px;">
						<input type="hidden" name="id" value="<?= $app['ID'] ?>">
						
						<label><strong>Mark as:</strong></label><br>
						<button type="submit" name="action" value="complete" style="background:#28a745; color:white; border:none; padding:5px 10px; border-radius:3px; margin-right:5px;">
							✓ Completed
						</button>
						
						<button type="submit" name="action" value="missed" style="background:#dc3545; color:white; border:none; padding:5px 10px; border-radius:3px; margin-right:5px;">
							✗ Missed
						</button>
						
						<br>
						<textarea name="outcome" placeholder="Brief outcome/notes (optional)" style="width:100%; margin-top:5px; padding:5px;"></textarea>
					</form>
				</div>
			<?php endwhile; ?>
		<?php endif; ?>
	</div>
	      <div class="card">
          <h3>Medical & Nutrition Management</h3>
          
          <div style="display: flex; gap: 10px; margin-bottom: 15px; flex-wrap: wrap;">
              <a href="../medical/view_medical_records.php?resident_id=<?php echo $resident['id']; ?>" 
                 style="background: #2196F3; color: white; padding: 10px 15px; border-radius: 5px; text-decoration: none; display: inline-block;">
                  <strong>Medical Records</strong>
              </a>
              
              <a href="../medical/add_medical_record.php?resident_id=<?php echo $resident['id']; ?>" 
                 style="background: #4CAF50; color: white; padding: 10px 15px; border-radius: 5px; text-decoration: none; display: inline-block;">
                  <strong>➕ Add Record</strong>
              </a>
              
              <a href="../allergies/manage_allergies.php?resident_id=<?php echo $resident['id']; ?>" 
                 style="background: #FF9800; color: white; padding: 10px 15px; border-radius: 5px; text-decoration: none; display: inline-block;">
                  <strong>Allergies</strong>
              </a>
              
              <a href="../meals/meal_plan.php?resident_id=<?php echo $resident['id']; ?>" 
                 style="background: #9C27B0; color: white; padding: 10px 15px; border-radius: 5px; text-decoration: none; display: inline-block;">
                  <strong>Meal Plan</strong>
              </a>
          </div>
          
          <!-- Quick allergy display -->
          <?php
          $quick_allergies = $conn->query("
              SELECT a.Allergy_Name, a.Severity 
              FROM Allergy a
              JOIN have_allergy ha ON a.ID = ha.Allergy_ID
              WHERE ha.R_ID = {$resident['id']} 
              LIMIT 3
          ");
          if ($quick_allergies->num_rows > 0): ?>
          <div style="background: #FFF3CD; padding: 10px; border-radius: 5px; margin-top: 10px;">
              <strong>⚠️ Current Allergies:</strong>
              <?php while($a = $quick_allergies->fetch_assoc()): 
                  $color = $a['Severity'] == 'Critical' ? '#DC3545' : 
                          ($a['Severity'] == 'High' ? '#FF5722' : 
                          ($a['Severity'] == 'Medium' ? '#FF9800' : '#4CAF50'));
              ?>
              <span style="background: <?php echo $color; ?>; color: white; padding: 3px 8px; border-radius: 3px; margin: 0 5px; display: inline-block; margin-top: 5px;">
                  <?php echo htmlspecialchars($a['Allergy_Name']); ?> (<?php echo $a['Severity']; ?>)
              </span>
              <?php endwhile; ?>
          </div>
          <?php endif; ?>
    </div>
	<?php endif; ?>

	<?php
	// FUTURE APPOINTMENTS (Approved and not yet occurred)
	$future_stmt = $conn->prepare("
		SELECT a.*, v.Name AS visitor_name
		FROM Appointment a
		JOIN Visitor v ON a.Visitor_ID = v.V_ID
		WHERE a.Resident_ID = ? 
		AND a.Status = 'Approved'
		AND (a.Requested_Date > CURDATE() OR (a.Requested_Date = CURDATE() AND a.Requested_Time > CURTIME()))
		ORDER BY a.Requested_Date ASC, a.Requested_Time ASC
	");
	$future_stmt->bind_param("i", $resident['id']);
	$future_stmt->execute();
	$future_apps = $future_stmt->get_result();
	?>

	<div class="card">
		<h3>Upcoming Appointments</h3>
		<?php if ($future_apps->num_rows === 0): ?>
			<p>No upcoming appointments.</p>
		<?php else: ?>
			<?php while($app = $future_apps->fetch_assoc()): ?>
				<div style="border:1px solid #28a745; padding:10px; margin-bottom:10px; border-radius:5px; background:#f8fff9;">
					<strong>Visitor:</strong> <?= htmlspecialchars($app['visitor_name']) ?><br>
					<strong>Date:</strong> <?= $app['Requested_Date'] ?> <strong>Time:</strong> <?= $app['Requested_Time'] ?><br>
					<strong>Scheduled By:</strong> <?= $app['Decision_By'] ?? 'N/A' ?>
				</div>
			<?php endwhile; ?>
		<?php endif; ?>
	</div>
  </div>
</body>
</html>

