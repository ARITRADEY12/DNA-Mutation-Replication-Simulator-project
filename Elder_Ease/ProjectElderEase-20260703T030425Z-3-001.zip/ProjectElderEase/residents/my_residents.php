<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit();
}
if (($_SESSION['role'] ?? '') !== 'caregiver') {
    $_SESSION['error'] = "Caregivers only.";
    header("Location: ../login.php");
    exit();
}

$care_id = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT r.ID AS id, r.Name AS name, r.Age AS age, r.Gender AS gender, r.R_Room_Number AS room
    FROM cares c
    JOIN Resident r ON c.Res_ID = r.ID
    WHERE c.Cr_ID = ?
    ORDER BY r.Name
");
$stmt->bind_param("i", $care_id);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Residents - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222}
    .top{background:linear-gradient(135deg,#2E7D32 0%,#4CAF50 100%);color:#fff}
    .wrap{max-width:980px;margin:0 auto;padding:16px 18px;display:flex;justify-content:space-between;align-items:center}
    a{color:#fff;text-decoration:none;font-weight:900}
    .container{max-width:980px;margin:18px auto;padding:0 18px}
    .card{background:#fff;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);padding:18px;border:1px solid #eef0f7}
    h1{font-size:22px;margin-bottom:6px}
    .sub{color:#666;margin-bottom:12px}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    th,td{padding:10px;border-bottom:1px solid #eef0f7;text-align:left}
    th{background:#f8fafc;font-weight:900;color:#333}
    .btn{display:inline-block;margin-top:10px;background:#2E7D32;color:#fff;text-decoration:none;font-weight:1000;padding:10px 12px;border-radius:12px}
    .btn:hover{filter:brightness(.95)}
  </style>
</head>
<body>
  <div class="top">
    <div class="wrap">
      <div style="font-weight:1000">My Residents</div>
      <div>
        <a href="../dashboard/caregiver.php">Caregiver Profile</a>
        &nbsp; | &nbsp;
        <a href="../logout.php">Logout</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="card">
      <h1>Assigned Residents</h1>
      <div class="sub">You can open each resident profile for details.</div>

      <?php if ($res->num_rows === 0): ?>
        <div style="color:#666">No residents assigned yet.</div>
        <a class="btn" href="add_resident.php">Add Resident</a>
      <?php else: ?>
        <table>
          <thead>
            <tr><th>Name</th><th>Age</th><th>Gender</th><th>Room</th><th>Profile</th></tr>
          </thead>
          <tbody>
            <?php while($r = $res->fetch_assoc()): ?>
              <tr>
                <td><?php echo htmlspecialchars($r['name']); ?></td>
                <td><?php echo htmlspecialchars($r['age'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($r['gender'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($r['room'] ?? 'N/A'); ?></td>
                <td><a href="resident_profile.php?id=<?php echo (int)$r['id']; ?>">View</a></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>

        <a class="btn" href="add_resident.php">Register New Resident</a>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>

