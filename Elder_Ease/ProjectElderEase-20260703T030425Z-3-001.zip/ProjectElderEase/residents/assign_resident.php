<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit();
}
if (($_SESSION['role'] ?? '') !== 'admin') {
    $_SESSION['error'] = "Admins only.";
    header("Location: ../login.php");
    exit();
}

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $resident_id = (int)($_POST['resident'] ?? 0);
    $caregiver_id = (int)($_POST['caregiver'] ?? 0);

    if ($resident_id <= 0 || $caregiver_id <= 0) {
        $err = "Please select both resident and caregiver.";
    } else {
        try {
            // Ensure resident exists
            $rchk = $conn->prepare("SELECT 1 FROM Resident WHERE ID=? LIMIT 1");
            $rchk->bind_param("i", $resident_id);
            $rchk->execute();
            if ($rchk->get_result()->num_rows === 0) {
                $err = "Resident not found.";
            } else {
                // Ensure caregiver exists
                $cchk = $conn->prepare("SELECT 1 FROM CareGiver WHERE C_ID=? LIMIT 1");
                $cchk->bind_param("i", $caregiver_id);
                $cchk->execute();
                if ($cchk->get_result()->num_rows === 0) {
                    $err = "Caregiver not found.";
                } else {
                    // Enforce single caregiver per resident (your requirement logic)
                    $chk = $conn->prepare("SELECT 1 FROM cares WHERE Res_ID=? LIMIT 1");
                    $chk->bind_param("i", $resident_id);
                    $chk->execute();

                    if ($chk->get_result()->num_rows > 0) {
                        $err = "Resident already assigned to a caregiver.";
                    } else {
                        $ins = $conn->prepare("INSERT INTO cares (Cr_ID, Res_ID) VALUES (?, ?)");
                        $ins->bind_param("ii", $caregiver_id, $resident_id);
                        $ins->execute();

                        $_SESSION['flash_success'] = "Resident assigned successfully.";
                        header("Location: ../dashboard/caregiver.php?view=" . $caregiver_id);
                        exit();
                    }
                }
            }
        } catch (mysqli_sql_exception $e) {
            $err = "Assignment failed: " . $e->getMessage();
        }
    }
}

$residents = $conn->query("SELECT ID, Name FROM Resident ORDER BY Name");
$caregivers = $conn->query("SELECT C_ID, Name FROM CareGiver ORDER BY Name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Assign Resident - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222}
    .top{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff}
    .wrap{max-width:980px;margin:0 auto;padding:16px 18px;display:flex;justify-content:space-between;align-items:center}
    a{color:#fff;text-decoration:none;font-weight:900}
    .container{max-width:980px;margin:18px auto;padding:0 18px}
    .card{background:#fff;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);padding:18px;border:1px solid #eef0f7}
    h1{font-size:22px;margin-bottom:6px}
    .sub{color:#666;margin-bottom:14px}
    .msg{padding:12px;border-radius:12px;margin-bottom:14px;border:1px solid}
    .err{background:#ffe9ea;border-color:#ffb2b7;color:#7a1020;font-weight:800}
    label{display:block;font-weight:900;margin:12px 0 6px}
    select{width:100%;padding:12px;border-radius:12px;border:2px solid #e7e7ef;font-size:15px}
    select:focus{outline:none;border-color:#667eea;box-shadow:0 0 0 3px rgba(102,126,234,.12)}
    .btn{margin-top:14px;width:100%;border:none;border-radius:12px;padding:12px;font-weight:1000;background:#667eea;color:#fff;cursor:pointer}
    .btn:hover{filter:brightness(.96)}
  </style>
</head>
<body>
  <div class="top">
    <div class="wrap">
      <div style="font-weight:1000">Assign Resident</div>
      <div>
        <a href="../dashboard/admin.php">Admin Dashboard</a>
        &nbsp; | &nbsp;
        <a href="../logout.php">Logout</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="card">
      <h1>Assign Resident to Caregiver</h1>
      <div class="sub">After assignment, you will be redirected to the caregiver profile (admin view).</div>

      <?php if ($err): ?>
        <div class="msg err"><?php echo htmlspecialchars($err); ?></div>
      <?php endif; ?>

      <form method="post">
        <label for="resident">Resident</label>
        <select id="resident" name="resident" required>
          <option value="">-- Select resident --</option>
          <?php while($r = $residents->fetch_assoc()): ?>
            <option value="<?php echo (int)$r['ID']; ?>"><?php echo htmlspecialchars($r['Name']); ?> (ID: <?php echo (int)$r['ID']; ?>)</option>
          <?php endwhile; ?>
        </select>

        <label for="caregiver">Caregiver</label>
        <select id="caregiver" name="caregiver" required>
          <option value="">-- Select caregiver --</option>
          <?php while($c = $caregivers->fetch_assoc()): ?>
            <option value="<?php echo (int)$c['C_ID']; ?>"><?php echo htmlspecialchars($c['Name']); ?> (ID: <?php echo (int)$c['C_ID']; ?>)</option>
          <?php endwhile; ?>
        </select>

        <button class="btn" type="submit">Assign</button>
      </form>
    </div>
  </div>
</body>
</html>

