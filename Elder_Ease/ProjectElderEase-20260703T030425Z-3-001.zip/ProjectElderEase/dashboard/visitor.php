<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit();
}

// Allow admin to view any visitor's profile with ?view=ID parameter
$target_id = (int)$_SESSION['user_id'];
$is_admin_view = false;

if (($_SESSION['role'] ?? '') === 'admin' && isset($_GET['view'])) {
    $target_id = (int)$_GET['view'];
    $is_admin_view = true;
    
    // Verify the target ID is a valid visitor
    $check = $conn->prepare("SELECT 1 FROM Visitor WHERE V_ID = ?");
    $check->bind_param("i", $target_id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        $_SESSION['error'] = "Visitor not found.";
        header("Location: admin.php");
        exit();
    }
} elseif (($_SESSION['role'] ?? '') !== 'visitor') {
    $_SESSION['error'] = "Access denied (Visitor only).";
    header("Location: ../login.php");
    exit();
}

// Now use $target_id instead of $_SESSION['user_id']
$vStmt = $conn->prepare("SELECT V_ID AS id, Name AS name, Contact AS contact FROM Visitor WHERE V_ID = ? LIMIT 1");
$vStmt->bind_param("i", $target_id);
$vStmt->execute();
$visitor = $vStmt->get_result()->fetch_assoc();

$visStmt = $conn->prepare("
    SELECT r.ID AS id, r.Name AS name, r.R_Room_Number AS room
    FROM visits v
    JOIN Resident r ON v.Res_ID = r.ID
    WHERE v.Vis_ID = ?
    ORDER BY r.Name
");
$visStmt->bind_param("i", $target_id);
$visStmt->execute();
$visited = $visStmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $is_admin_view ? 'View Visitor (Admin)' : 'Visitor'; ?> - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222}
    .layout{display:flex;min-height:100vh}
    .side{width:260px;background:linear-gradient(135deg,#F57C00 0%,#FF9800 100%);color:#fff;padding:18px}
    .brand{font-weight:900;font-size:18px}
    .who{margin-top:10px;opacity:.9;font-size:13px}
    .menu{list-style:none;margin-top:18px}
    .menu a{display:block;color:#fff;text-decoration:none;padding:10px 12px;border-radius:12px;margin-bottom:8px}
    .menu a:hover{background:rgba(255,255,255,.12)}
    .menu a.active{background:rgba(255,255,255,.20);font-weight:900}
    .main{flex:1;padding:20px}
    .top{display:flex;justify-content:space-between;align-items:center;background:#fff;border-radius:16px;padding:16px 18px;box-shadow:0 10px 30px rgba(0,0,0,.06)}
    .btn{display:inline-block;text-decoration:none;font-weight:900;border-radius:12px;padding:10px 14px}
    .btn-red{background:#dc3545;color:#fff}
    .btn-red:hover{filter:brightness(.95)}
    .btn-blue{background:#667eea;color:#fff}
    .btn-blue:hover{filter:brightness(.95)}
    .card{margin-top:12px;background:#fff;border-radius:16px;padding:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);border:1px solid #eef0f7}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    th,td{padding:10px;border-bottom:1px solid #eef0f7;text-align:left}
    th{background:#f8fafc;font-weight:900;color:#333}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:10px}
    .k{color:#666;font-weight:900;font-size:12px;text-transform:uppercase;letter-spacing:.8px}
    .v{margin-top:6px;font-weight:800}
    @media(max-width:900px){.layout{flex-direction:column}.side{width:100%}}
    /* Appointment status colors */
    .status-badge {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
    }
    .status-pending { background: #fff3cd; color: #856404; }
    .status-approved { background: #d4edda; color: #155724; }
    .status-declined { background: #f8d7da; color: #721c24; }
    .status-completed { background: #d1ecf1; color: #0c5460; }
    .status-missed { background: #e2e3e5; color: #383d41; }
    /* Appointment cards */
    .appointment-card {
        border-left: 4px solid;
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 8px;
        background: #fff;
    }
    .appointment-pending { border-left-color: #ffc107; background: #fffdf6; }
    .appointment-approved { border-left-color: #28a745; background: #f8fff9; }
    .appointment-completed { border-left-color: #17a2b8; background: #f0f9fb; }
    .appointment-missed { border-left-color: #6c757d; background: #f8f9fa; }
    .admin-banner {
        background: #667eea;
        color: white;
        padding: 8px 12px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-weight: 700;
    }
  </style>
</head>
<body>
  <div class="layout">
    <aside class="side">
      <div class="brand">ElderEase</div>
      <div class="who">
        <?php if ($is_admin_view): ?>
          Admin Viewing Visitor
        <?php else: ?>
          Visitor Portal
        <?php endif; ?>
      </div>
      <ul class="menu">
        <li><a class="active" href="visitor.php<?php echo $is_admin_view ? '?view=' . $target_id : ''; ?>">Dashboard</a></li>
        <?php if ($is_admin_view): ?>
          <li><a href="admin.php">Back to Admin</a></li>
        <?php endif; ?>
      </ul>
    </aside>

    <main class="main">
      <div class="top">
        <?php if (!empty($_SESSION['flash_success'])): ?>
          <div class="card" style="background:#e6fffa;border:1px solid #38b2ac;color:#065f46;">
            <?php echo htmlspecialchars($_SESSION['flash_success']); ?>
          </div>
          <?php unset($_SESSION['flash_success']); ?>
        <?php endif; ?>
        <div>
          <div style="font-weight:1000;font-size:18px">
            <?php echo $is_admin_view ? 'Viewing Visitor (Admin Mode)' : 'Visitor Dashboard'; ?>
          </div>
          <div style="color:#666;margin-top:3px">
            <?php if ($is_admin_view): ?>
              Admin: <?php echo htmlspecialchars($_SESSION['username']); ?> viewing 
              <?php echo htmlspecialchars($visitor['name'] ?? 'Visitor'); ?>
            <?php else: ?>
              Logged in as <?php echo htmlspecialchars($_SESSION['username']); ?>
            <?php endif; ?>
          </div>
        </div>
        <div>
          <?php if ($is_admin_view): ?>
            <a class="btn btn-blue" href="admin.php">Back to Admin</a>
          <?php endif; ?>
          <a class="btn btn-red" href="../logout.php">Logout</a>
        </div>
      </div>

      <?php if ($is_admin_view): ?>
        <div class="admin-banner">
          ⚡ Admin Mode: You are viewing visitor "<?php echo htmlspecialchars($visitor['name']); ?>" (ID: <?php echo $target_id; ?>)
        </div>
      <?php endif; ?>

      <div class="card">
        <div class="grid">
          <div><div class="k">Name</div><div class="v"><?php echo htmlspecialchars($visitor['name'] ?? 'N/A'); ?></div></div>
          <div><div class="k">Contact</div><div class="v"><?php echo htmlspecialchars($visitor['contact'] ?? 'N/A'); ?></div></div>
          <div><div class="k">User ID</div><div class="v"><?php echo (int)$target_id; ?></div></div>
          <?php if ($is_admin_view): ?>
            <div><div class="k">Mode</div><div class="v" style="color:#667eea;">Admin View</div></div>
          <?php endif; ?>
        </div>
      </div>
      
      <?php if (!$is_admin_view): ?>
        <div class="card">
          <h2>Appointments</h2>
          <a href="../appointments/request_appointment.php"
             style="display:inline-block;
                    padding:10px 14px;
                    background:#F57C00;
                    color:white;
                    border-radius:8px;
                    text-decoration:none;">
            Request Appointment
          </a>
        </div>
      <?php endif; ?>
      
      <div class="card">
        <div style="font-weight:1000;margin-bottom:6px">Visited Residents</div>
        <?php if ($visited->num_rows === 0): ?>
          <div style="color:#666">No visit mapping found yet.</div>
        <?php else: ?>
          <table>
            <thead><tr><th>Resident</th><th>Room</th><th>Profile</th></tr></thead>
            <tbody>
              <?php while ($r = $visited->fetch_assoc()): ?>
                <tr>
                  <td><?php echo htmlspecialchars($r['name']); ?></td>
                  <td><?php echo htmlspecialchars($r['room'] ?? 'N/A'); ?></td>
                  <td><a href="../residents/resident_profile.php?id=<?php echo (int)$r['id']; ?>">View</a></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
      
      <?php
      // Get approved appointments
      $apps = $conn->prepare("
        SELECT a.*, r.Name AS resident
        FROM Appointment a
        JOIN Resident r ON a.Resident_ID = r.ID
        WHERE a.Visitor_ID=? AND a.Status='Approved'
      ");
      $apps->bind_param("i", $target_id);
      $apps->execute();
      $res = $apps->get_result();
      ?>
      <div class="card">
        <h3>Confirmed Appointments</h3>
        <?php if ($res->num_rows === 0): ?>
          <p>No confirmed appointments.</p>
        <?php else: ?>
          <?php while($a=$res->fetch_assoc()): ?>
          <div class="appointment-card appointment-approved">
            <strong>Resident:</strong> <?= htmlspecialchars($a['resident']) ?><br>
            <strong>Date:</strong> <?= $a['Requested_Date'] ?> <strong>Time:</strong> <?= $a['Requested_Time'] ?><br>
            <?php if ($a['Decision_By']): ?>
              <small>Approved by: <?= $a['Decision_By'] ?></small>
            <?php endif; ?>
          </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
      
      <?php
      // FUTURE APPOINTMENTS (Approved but not yet occurred)
      $future_stmt = $conn->prepare("
        SELECT a.*, r.Name AS resident
        FROM Appointment a
        JOIN Resident r ON a.Resident_ID = r.ID
        WHERE a.Visitor_ID = ? 
        AND a.Status = 'Approved'
        AND (a.Requested_Date > CURDATE() OR (a.Requested_Date = CURDATE() AND a.Requested_Time > CURTIME()))
        ORDER BY a.Requested_Date ASC, a.Requested_Time ASC
      ");
      $future_stmt->bind_param("i", $target_id);
      $future_stmt->execute();
      $future_apps = $future_stmt->get_result();
      ?>

      <div class="card">
        <h3>Upcoming Appointments</h3>
        <?php if ($future_apps->num_rows === 0): ?>
          <p>No upcoming appointments.</p>
        <?php else: ?>
          <?php while($app = $future_apps->fetch_assoc()): ?>
            <div class="appointment-card appointment-approved">
              <strong>Resident:</strong> <?= htmlspecialchars($app['resident']) ?><br>
              <strong>Date:</strong> <?= $app['Requested_Date'] ?> <strong>Time:</strong> <?= $app['Requested_Time'] ?><br>
              <span class="status-badge status-approved">Approved</span>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>

      <?php
      // APPOINTMENT HISTORY (Completed/Missed)
      $history_stmt = $conn->prepare("
        SELECT a.*, r.Name AS resident
        FROM Appointment a
        JOIN Resident r ON a.Resident_ID = r.ID
        WHERE a.Visitor_ID = ? 
        AND a.Status IN ('Completed', 'Missed')
        ORDER BY a.Requested_Date DESC, a.Requested_Time DESC
        LIMIT 20
      ");
      $history_stmt->bind_param("i", $target_id);
      $history_stmt->execute();
      $history = $history_stmt->get_result();
      ?>

      <div class="card">
        <h3>Appointment History</h3>
        <?php if ($history->num_rows === 0): ?>
          <p>No appointment history.</p>
        <?php else: ?>
          <table style="width:100%; border-collapse:collapse;">
            <thead>
              <tr style="background:#f8f9fa;">
                <th style="padding:8px; border-bottom:1px solid #dee2e6;">Resident</th>
                <th style="padding:8px; border-bottom:1px solid #dee2e6;">Date & Time</th>
                <th style="padding:8px; border-bottom:1px solid #dee2e6;">Status</th>
                <th style="padding:8px; border-bottom:1px solid #dee2e6;">Outcome</th>
              </tr>
            </thead>
            <tbody>
              <?php while($app = $history->fetch_assoc()): ?>
                <tr>
                  <td style="padding:8px; border-bottom:1px solid #dee2e6;"><?= htmlspecialchars($app['resident']) ?></td>
                  <td style="padding:8px; border-bottom:1px solid #dee2e6;"><?= $app['Requested_Date'] ?> <?= $app['Requested_Time'] ?></td>
                  <td style="padding:8px; border-bottom:1px solid #dee2e6;">
                    <span class="status-badge status-<?= strtolower($app['Status']) ?>">
                      <?= $app['Status'] ?>
                    </span>
                  </td>
                  <td style="padding:8px; border-bottom:1px solid #dee2e6;"><?= htmlspecialchars($app['Visit_Outcome'] ?? 'N/A') ?></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
      
      <?php
      // Pending appointments - only show to admin or the visitor themselves
      $pending_stmt = $conn->prepare("
        SELECT a.*, r.Name AS resident
        FROM Appointment a
        JOIN Resident r ON a.Resident_ID = r.ID
        WHERE a.Visitor_ID = ? 
        AND a.Status = 'Pending'
        ORDER BY a.Requested_Date ASC, a.Requested_Time ASC
      ");
      $pending_stmt->bind_param("i", $target_id);
      $pending_stmt->execute();
      $pending_apps = $pending_stmt->get_result();
      
      if ($pending_apps->num_rows > 0 && $is_admin_view):
      ?>
      <div class="card">
        <h3>Pending Appointment Requests (Admin Actions)</h3>
        <?php while($app = $pending_apps->fetch_assoc()): ?>
          <div class="appointment-card appointment-pending">
            <div style="display:flex;justify-content:space-between;align-items:start">
              <div>
                <strong>Resident:</strong> <?= htmlspecialchars($app['resident']) ?><br>
                <strong>Date:</strong> <?= $app['Requested_Date'] ?> 
                <strong>Time:</strong> <?= $app['Requested_Time'] ?>
              </div>
              <span class="status-badge status-pending">Pending</span>
            </div>
            <div style="margin-top:8px">
              <form method="post" action="../appointments/decision.php" style="display:inline;">
                <input type="hidden" name="id" value="<?= $app['ID'] ?>">
                <button type="submit" name="action" value="approve" style="background:#28a745;color:white;border:none;padding:6px 12px;border-radius:4px;cursor:pointer">
                  ✓ Approve
                </button>
                <button type="submit" name="action" value="decline" style="background:#dc3545;color:white;border:none;padding:6px 12px;border-radius:4px;cursor:pointer">
                  ✗ Decline
                </button>
                <textarea name="reason" placeholder="Reason if declined" style="margin-left:10px;padding:4px;width:200px;"></textarea>
              </form>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
      <?php endif; ?>
    </main>
  </div>
</body>
</html>

