<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit();
}

$role = $_SESSION['role'] ?? '';
$is_admin = ($role === 'admin');
$is_caregiver = ($role === 'caregiver');

if (!$is_admin && !$is_caregiver) {
    $_SESSION['error'] = "Access denied.";
    header("Location: ../login.php");
    exit();
}

// Admin can view caregiver profile using ?view=ID
$target_id = (int)($_SESSION['user_id']);
if ($is_admin && isset($_GET['view'])) {
    $target_id = (int)$_GET['view'];
    if ($target_id <= 0) $target_id = (int)$_SESSION['user_id'];
}

$cgStmt = $conn->prepare("SELECT C_ID AS id, Name AS name, Email AS email FROM CareGiver WHERE C_ID = ? LIMIT 1");
$cgStmt->bind_param("i", $target_id);
$cgStmt->execute();
$caregiver = $cgStmt->get_result()->fetch_assoc();

if (!$caregiver) {
    $_SESSION['error'] = "Caregiver not found.";
    header("Location: " . ($is_admin ? "admin.php" : "../login.php"));
    exit();
}

// Assigned residents
$resStmt = $conn->prepare("
    SELECT r.ID AS id, r.Name AS name, r.Age AS age, r.Gender AS gender, r.Health_Status AS health, r.R_Room_Number AS room
    FROM cares c
    JOIN Resident r ON c.Res_ID = r.ID
    WHERE c.Cr_ID = ?
    ORDER BY r.Name
");
$resStmt->bind_param("i", $target_id);
$resStmt->execute();
$resList = $resStmt->get_result();

// Get pending appointments for this caregiver's residents
$pending_stmt = $conn->prepare("
    SELECT a.*, v.Name AS visitor_name, r.Name AS resident_name
    FROM Appointment a
    JOIN Visitor v ON a.Visitor_ID = v.V_ID
    JOIN Resident r ON a.Resident_ID = r.ID
    WHERE a.Status = 'Pending' 
    AND a.Resident_ID IN (
        SELECT Res_ID FROM cares WHERE Cr_ID = ?
    )
    ORDER BY a.Requested_Date, a.Requested_Time
");
$pending_stmt->bind_param("i", $target_id);
$pending_stmt->execute();
$pending_appointments = $pending_stmt->get_result();

$flash = $_SESSION['flash_success'] ?? '';
unset($_SESSION['flash_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Caregiver - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222}
    .layout{display:flex;min-height:100vh}
    .side{width:260px;background:linear-gradient(135deg,#2E7D32 0%,#4CAF50 100%);color:#fff;padding:18px}
    .brand{font-weight:900;font-size:18px}
    .who{margin-top:10px;opacity:.9;font-size:13px}
    .menu{list-style:none;margin-top:18px}
    .menu a{display:block;color:#fff;text-decoration:none;padding:10px 12px;border-radius:12px;margin-bottom:8px}
    .menu a:hover{background:rgba(255,255,255,.12)}
    .menu a.active{background:rgba(255,255,255,.20);font-weight:900}
    .main{flex:1;padding:20px}
    .top{display:flex;justify-content:space-between;align-items:center;background:#fff;border-radius:16px;padding:16px 18px;box-shadow:0 10px 30px rgba(0,0,0,.06)}
    .btn{display:inline-block;text-decoration:none;font-weight:900;border-radius:12px;padding:10px 14px}
    .btn-red{background:#dc3545;color:#fff}
    .btn-red:hover{filter:brightness(.95)}
    .btn-green{background:#2E7D32;color:#fff}
    .btn-green:hover{filter:brightness(.95)}
    .card{margin-top:12px;background:#fff;border-radius:16px;padding:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);border:1px solid #eef0f7}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:10px}
    .k{color:#666;font-weight:900;font-size:12px;text-transform:uppercase;letter-spacing:.8px}
    .v{margin-top:6px;font-weight:800}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    th,td{padding:10px;border-bottom:1px solid #eef0f7;text-align:left}
    th{background:#f8fafc;font-weight:900;color:#333}
    .msg{margin-top:12px;background:#e9fff1;border:1px solid #b7f0c7;color:#0f5132;padding:12px;border-radius:14px;font-weight:700}
    @media(max-width:900px){.layout{flex-direction:column}.side{width:100%}}
	/* Appointment status colors */
	.status-badge {
		display: inline-block;
		padding: 3px 8px;
		border-radius: 12px;
		font-size: 12px;
		font-weight: 700;
	}
	.status-pending { background: #fff3cd; color: #856404; }
	.status-approved { background: #d4edda; color: #155724; }
	.status-declined { background: #f8d7da; color: #721c24; }
	.status-completed { background: #d1ecf1; color: #0c5460; }
	.status-missed { background: #e2e3e5; color: #383d41; }

	/* Appointment cards */
	.appointment-card {
		border-left: 4px solid;
		margin-bottom: 10px;
		padding: 10px;
		border-radius: 8px;
		background: #fff;
	}
	.appointment-pending { 
		border-left-color: #ffc107; 
		background: #fffdf6; 
	}
	.appointment-approved { 
		border-left-color: #28a745; 
		background: #f8fff9; 
	}
	.appointment-declined { 
		border-left-color: #dc3545; 
		background: #fff5f5; 
	}
	.appointment-completed { 
		border-left-color: #17a2b8; 
		background: #f0f9fb; 
	}
	.appointment-missed { 
		border-left-color: #6c757d; 
		background: #f8f9fa; 
	}
	
	/* Appointment actions */
	.appointment-actions {
		margin-top: 8px;
		display: flex;
		gap: 8px;
		flex-wrap: wrap;
	}
	
	.action-btn {
		padding: 6px 12px;
		border: none;
		border-radius: 6px;
		font-size: 12px;
		font-weight: 600;
		cursor: pointer;
		transition: all 0.2s;
	}
	
	.approve-btn {
		background: #28a745;
		color: white;
	}
	
	.approve-btn:hover {
		background: #218838;
	}
	
	.decline-btn {
		background: #dc3545;
		color: white;
	}
	
	.decline-btn:hover {
		background: #c82333;
	}
	
	.decline-reason-box {
		margin-top: 8px;
		padding: 10px;
		background: #f8f9fa;
		border-radius: 6px;
		border: 1px solid #dee2e6;
		display: none;
	}
	
	.reason-textarea {
		width: 100%;
		padding: 8px;
		border: 1px solid #ccc;
		border-radius: 4px;
		font-size: 14px;
		resize: vertical;
		margin-bottom: 8px;
	}
	
	.reason-submit-btn {
		background: #dc3545;
		color: white;
		border: none;
		padding: 6px 12px;
		border-radius: 4px;
		font-size: 12px;
		cursor: pointer;
	}
	
	.reason-cancel-btn {
		background: #6c757d;
		color: white;
		border: none;
		padding: 6px 12px;
		border-radius: 4px;
		font-size: 12px;
		cursor: pointer;
		margin-left: 5px;
	}
  </style>
</head>
<body>
  <div class="layout">
    <aside class="side">
      <div class="brand">ElderEase</div>
      <div class="who">
        <?php if ($is_admin): ?>
          Admin viewing caregiver
        <?php else: ?>
          Caregiver Portal
        <?php endif; ?>
      </div>

      <ul class="menu">
        <li><a class="active" href="caregiver.php<?php echo $is_admin ? '?view=' . (int)$caregiver['id'] : ''; ?>">Profile</a></li>

        <?php if (!$is_admin): ?>
          <li><a href="../residents/my_residents.php">My Residents</a></li>
          <li><a href="../residents/add_resident.php">Add Resident</a></li>
        <?php else: ?>
          <li><a href="admin.php">Back to Admin</a></li>
          <li><a href="../residents/assign_resident.php">Assign Resident</a></li>
        <?php endif; ?>
      </ul>
    </aside>

    <main class="main">
      <div class="top">
        <div>
          <div style="font-weight:1000;font-size:18px">Caregiver Profile</div>
          <div style="color:#666;margin-top:3px">
            <?php echo htmlspecialchars($caregiver['name']); ?> (ID: <?php echo (int)$caregiver['id']; ?>)
          </div>
        </div>
        <a class="btn btn-red" href="../logout.php">Logout</a>
      </div>

      <?php if ($flash): ?>
        <div class="msg"><?php echo htmlspecialchars($flash); ?></div>
      <?php endif; ?>

      <div class="card">
        <div class="grid">
          <div><div class="k">Name</div><div class="v"><?php echo htmlspecialchars($caregiver['name']); ?></div></div>
          <div><div class="k">Email</div><div class="v"><?php echo htmlspecialchars($caregiver['email'] ?? 'N/A'); ?></div></div>
          <div><div class="k">Username</div><div class="v"><?php echo htmlspecialchars($_SESSION['username']); ?></div></div>
          <div><div class="k">Mode</div><div class="v"><?php echo $is_admin ? 'Admin View' : 'Caregiver View'; ?></div></div>
        </div>

        <!-- REMOVED THE BUTTONS HERE -->
      </div>

      <div class="card">
        <div style="font-weight:1000;margin-bottom:6px">Assigned Residents</div>

        <?php if ($resList->num_rows === 0): ?>
          <div style="color:#666">No residents assigned.</div>
        <?php else: ?>
          <table>
            <thead>
              <tr>
                <th>Resident</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Room</th>
                <th>Profile</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($r = $resList->fetch_assoc()): ?>
                <tr>
                  <td><?php echo htmlspecialchars($r['name']); ?></td>
                  <td><?php echo htmlspecialchars($r['age'] ?? ''); ?></td>
                  <td><?php echo htmlspecialchars($r['gender'] ?? ''); ?></td>
                  <td><?php echo htmlspecialchars($r['room'] ?? 'N/A'); ?></td>
                  <td><a href="../residents/resident_profile.php?id=<?php echo (int)$r['id']; ?>">View</a></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
      
      <!-- Pending Appointment Requests -->
      <div class="card">
        <div style="font-weight:1000;margin-bottom:12px">Pending Appointment Requests</div>
        
        <?php if ($pending_appointments->num_rows === 0): ?>
          <p style="color:#666">No pending appointment requests.</p>
        <?php else: ?>
          <?php while($app = $pending_appointments->fetch_assoc()): ?>
            <div class="appointment-card appointment-pending">
              <div style="display:flex;justify-content:space-between;align-items:start">
                <div>
                  <strong><?php echo htmlspecialchars($app['visitor_name']); ?></strong> → 
                  <strong><?php echo htmlspecialchars($app['resident_name']); ?></strong><br>
                  <small><?php echo $app['Requested_Date']; ?> at <?php echo $app['Requested_Time']; ?></small>
                </div>
                <span class="status-badge status-pending">
                  Pending
                </span>
              </div>
              
              <div class="appointment-actions">
                <form method="post" action="../appointments/decision.php" style="display:inline;">
                  <input type="hidden" name="id" value="<?php echo $app['ID']; ?>">
                  <button type="submit" name="action" value="approve" class="action-btn approve-btn">
                    ✓ Approve
                  </button>
                </form>
                
                <button type="button" class="action-btn decline-btn decline-trigger" data-appointment-id="<?php echo $app['ID']; ?>">
                  ✗ Decline
                </button>
              </div>
              
              <div id="decline-box-<?php echo $app['ID']; ?>" class="decline-reason-box">
                <form method="post" action="../appointments/decision.php" class="decline-form">
                  <input type="hidden" name="id" value="<?php echo $app['ID']; ?>">
                  <input type="hidden" name="action" value="decline">
                  <textarea name="reason" class="reason-textarea" placeholder="Enter reason for declining this appointment..." required></textarea>
                  <div>
                    <button type="submit" class="reason-submit-btn">Submit Decline</button>
                    <button type="button" class="reason-cancel-btn" onclick="cancelDecline(<?php echo $app['ID']; ?>)">Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <script>
    // Handle decline button clicks
    document.querySelectorAll('.decline-trigger').forEach(button => {
      button.addEventListener('click', function() {
        const appointmentId = this.getAttribute('data-appointment-id');
        const declineBox = document.getElementById('decline-box-' + appointmentId);
        
        // Hide all other decline boxes
        document.querySelectorAll('.decline-reason-box').forEach(box => {
          box.style.display = 'none';
        });
        
        // Toggle this decline box
        if (declineBox.style.display === 'block') {
          declineBox.style.display = 'none';
        } else {
          declineBox.style.display = 'block';
          declineBox.querySelector('textarea').focus();
        }
      });
    });
    
    function cancelDecline(appointmentId) {
      const declineBox = document.getElementById('decline-box-' + appointmentId);
      declineBox.style.display = 'none';
      declineBox.querySelector('textarea').value = '';
    }
    
    // Handle form submission
    document.querySelectorAll('.decline-form').forEach(form => {
      form.addEventListener('submit', function(e) {
        const textarea = this.querySelector('textarea');
        if (textarea.value.trim() === '') {
          e.preventDefault();
          alert('Please enter a reason for declining.');
          textarea.focus();
        }
      });
    });
  </script>
</body>
</html>