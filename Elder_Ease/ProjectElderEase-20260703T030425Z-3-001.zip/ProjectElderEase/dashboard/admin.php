<?php
session_start();
require_once __DIR__ . "/../connection.php";

if (empty($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit();
}
if (($_SESSION['role'] ?? '') !== 'admin') {
    $_SESSION['error'] = "Access denied (Admin only).";
    header("Location: ../login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

$adminStmt = $conn->prepare("SELECT Name AS name FROM Admin WHERE A_ID = ? LIMIT 1");
$adminStmt->bind_param("i", $user_id);
$adminStmt->execute();
$admin = $adminStmt->get_result()->fetch_assoc();

// Dashboard statistics
$total_users = (int)($conn->query("SELECT COUNT(*) c FROM User_login")->fetch_assoc()['c'] ?? 0);
$total_caregivers = (int)($conn->query("SELECT COUNT(*) c FROM CareGiver")->fetch_assoc()['c'] ?? 0);
$total_visitors = (int)($conn->query("SELECT COUNT(*) c FROM Visitor")->fetch_assoc()['c'] ?? 0);
$total_residents = (int)($conn->query("SELECT COUNT(*) c FROM Resident")->fetch_assoc()['c'] ?? 0);

// Appointment statistics
$pending_appointments = (int)($conn->query("SELECT COUNT(*) c FROM Appointment WHERE Status='Pending'")->fetch_assoc()['c'] ?? 0);
$approved_appointments = (int)($conn->query("SELECT COUNT(*) c FROM Appointment WHERE Status='Approved'")->fetch_assoc()['c'] ?? 0);
$today_appointments = (int)($conn->query("SELECT COUNT(*) c FROM Appointment WHERE Requested_Date = CURDATE() AND Status='Approved'")->fetch_assoc()['c'] ?? 0);

// Get all users for admin to view
$caregivers = $conn->query("SELECT C_ID, Name FROM CareGiver ORDER BY Name LIMIT 10");
$visitors = $conn->query("SELECT V_ID, Name FROM Visitor ORDER BY Name LIMIT 10");
$residents = $conn->query("SELECT ID, Name FROM Resident ORDER BY Name LIMIT 10");

// Get pending appointments
$pending_stmt = $conn->prepare("
    SELECT a.*, v.Name AS visitor_name, r.Name AS resident_name
    FROM Appointment a
    JOIN Visitor v ON a.Visitor_ID = v.V_ID
    JOIN Resident r ON a.Resident_ID = r.ID
    WHERE a.Status = 'Pending'
    ORDER BY a.Requested_Date, a.Requested_Time
");
$pending_stmt->execute();
$pending_appointments_list = $pending_stmt->get_result();

$flash = $_SESSION['flash_success'] ?? '';
unset($_SESSION['flash_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{background:#f6f7fb;color:#222}
    .layout{display:flex;min-height:100vh}
    .side{width:260px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:18px}
    .brand{font-weight:900;font-size:18px}
    .who{margin-top:10px;opacity:.9;font-size:13px}
    .menu{list-style:none;margin-top:18px}
    .menu a{display:block;color:#fff;text-decoration:none;padding:10px 12px;border-radius:12px;margin-bottom:8px}
    .menu a:hover{background:rgba(255,255,255,.12)}
    .menu a.active{background:rgba(255,255,255,.20);font-weight:900}
    .main{flex:1;padding:20px}
    .top{display:flex;justify-content:space-between;align-items:center;background:#fff;border-radius:16px;padding:16px 18px;box-shadow:0 10px 30px rgba(0,0,0,.06)}
    .btn{display:inline-block;text-decoration:none;font-weight:900;border-radius:12px;padding:10px 14px}
    .btn-red{background:#dc3545;color:#fff}
    .btn-red:hover{filter:brightness(.95)}
    .grid{margin-top:14px;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
    .card{background:#fff;border-radius:16px;padding:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);border:1px solid #eef0f7}
    .k{color:#666;font-weight:800;font-size:12px;text-transform:uppercase;letter-spacing:.8px}
    .v{font-size:34px;font-weight:1000;margin-top:6px}
    .actions{margin-top:12px;display:flex;gap:10px;flex-wrap:wrap}
    .btn-blue{background:#667eea;color:#fff}
    .btn-blue:hover{filter:brightness(.96)}
    .msg{margin-top:12px;background:#e9fff1;border:1px solid #b7f0c7;color:#0f5132;padding:12px;border-radius:14px;font-weight:700}
    @media(max-width:900px){.layout{flex-direction:column}.side{width:100%}}
    
    /* Appointment status colors */
    .status-badge {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
    }
    .status-pending { background: #fff3cd; color: #856404; }
    .status-approved { background: #d4edda; color: #155724; }
    .status-declined { background: #f8d7da; color: #721c24; }
    .status-completed { background: #d1ecf1; color: #0c5460; }
    .status-missed { background: #e2e3e5; color: #383d41; }
    
    /* Appointment cards */
    .appointment-card {
        border-left: 4px solid;
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 8px;
        background: #fff;
    }
    .appointment-pending { 
        border-left-color: #ffc107; 
        background: #fffdf6; 
    }
    .appointment-approved { 
        border-left-color: #28a745; 
        background: #f8fff9; 
    }
    .appointment-declined { 
        border-left-color: #dc3545; 
        background: #fff5f5; 
    }
    .appointment-completed { 
        border-left-color: #17a2b8; 
        background: #f0f9fb; 
    }
    .appointment-missed { 
        border-left-color: #6c757d; 
        background: #f8f9fa; 
    }
    
    /* User lists */
    .user-list {margin-top: 10px;}
    .user-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 0;
        border-bottom: 1px solid #eee;
    }
    .user-item:last-child {border-bottom: none;}
    .user-name {font-weight: 600;}
    .user-id {color: #666; font-size: 12px;}
    .view-link {
        background: #667eea;
        color: white;
        padding: 4px 8px;
        border-radius: 6px;
        text-decoration: none;
        font-size: 12px;
    }
    .view-link:hover {filter: brightness(.95);}
    
    /* Section headers */
    .section-title {
        font-weight: 1000;
        margin: 20px 0 10px;
        padding-bottom: 8px;
        border-bottom: 2px solid #eef0f7;
    }
    
    /* Quick stats */
    .stat-small {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px;
        background: #f8fafc;
        border-radius: 8px;
        margin-bottom: 8px;
    }
    .stat-icon {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
    }
    .stat-icon.pending {background: #fff3cd; color: #856404;}
    .stat-icon.approved {background: #d4edda; color: #155724;}
    .stat-icon.today {background: #d1ecf1; color: #0c5460;}
    
    /* Appointment actions */
    .appointment-actions {
        margin-top: 8px;
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .action-btn {
        padding: 6px 12px;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .approve-btn {
        background: #28a745;
        color: white;
    }
    
    .approve-btn:hover {
        background: #218838;
    }
    
    .decline-btn {
        background: #dc3545;
        color: white;
    }
    
    .decline-btn:hover {
        background: #c82333;
    }
    
    .decline-reason-box {
        margin-top: 8px;
        padding: 10px;
        background: #f8f9fa;
        border-radius: 6px;
        border: 1px solid #dee2e6;
        display: none;
    }
    
    .reason-textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
        resize: vertical;
        margin-bottom: 8px;
    }
    
    .reason-submit-btn {
        background: #dc3545;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 12px;
        cursor: pointer;
    }
    
    .reason-cancel-btn {
        background: #6c757d;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 12px;
        cursor: pointer;
        margin-left: 5px;
    }
  </style>
</head>
<body>
  <div class="layout">
    <aside class="side">
      <div class="brand">ElderEase</div>
      <div class="who">Admin: <?php echo htmlspecialchars($admin['name'] ?? $_SESSION['username']); ?></div>

      <ul class="menu">
        <li><a class="active" href="admin.php">Dashboard</a></li>
        <li><a href="../residents/add_resident.php">Add Resident</a></li>
        <li><a href="../residents/assign_resident.php">Assign Resident</a></li>
      </ul>
    </aside>

    <main class="main">
      <div class="top">
        <div>
          <div style="font-weight:1000;font-size:18px">Admin Dashboard</div>
          <div style="color:#666;margin-top:3px">
            Logged in as <?php echo htmlspecialchars($_SESSION['username']); ?> | 
            Full Admin Access
          </div>
        </div>
        <a class="btn btn-red" href="../logout.php">Logout</a>
      </div>

      <?php if ($flash): ?>
        <div class="msg"><?php echo htmlspecialchars($flash); ?></div>
      <?php endif; ?>

      <div class="grid">
        <div class="card"><div class="k">Total Users</div><div class="v"><?php echo $total_users; ?></div></div>
        <div class="card"><div class="k">Caregivers</div><div class="v"><?php echo $total_caregivers; ?></div></div>
        <div class="card"><div class="k">Visitors</div><div class="v"><?php echo $total_visitors; ?></div></div>
        <div class="card"><div class="k">Residents</div><div class="v"><?php echo $total_residents; ?></div></div>
      </div>

      <!-- Appointment Statistics -->
      <div class="card" style="margin-top:20px">
        <div style="font-weight:1000;margin-bottom:12px">Appointment Overview</div>
        <div class="stat-small">
          <div class="stat-icon pending">⏳</div>
          <div>
            <div style="font-weight:700">Pending Requests</div>
            <div style="font-size:20px;font-weight:900"><?php echo $pending_appointments; ?></div>
          </div>
        </div>
        <div class="stat-small">
          <div class="stat-icon approved">✓</div>
          <div>
            <div style="font-weight:700">Approved Appointments</div>
            <div style="font-size:20px;font-weight:900"><?php echo $approved_appointments; ?></div>
          </div>
        </div>
        <div class="stat-small">
          <div class="stat-icon today">📅</div>
          <div>
            <div style="font-weight:700">Today's Appointments</div>
            <div style="font-size:20px;font-weight:900"><?php echo $today_appointments; ?></div>
          </div>
        </div>
      </div>

      <!-- Quick Access to Profiles -->
      <div class="card" style="margin-top:20px">
        <div style="font-weight:1000;margin-bottom:12px">Quick Access</div>
        
        <div class="section-title">Caregivers</div>
        <div class="user-list">
          <?php if ($caregivers->num_rows === 0): ?>
            <p style="color:#666">No caregivers found.</p>
          <?php else: ?>
            <?php while($cg = $caregivers->fetch_assoc()): ?>
              <div class="user-item">
                <div>
                  <div class="user-name"><?php echo htmlspecialchars($cg['Name']); ?></div>
                  <div class="user-id">ID: <?php echo $cg['C_ID']; ?></div>
                </div>
                <a href="caregiver.php?view=<?php echo $cg['C_ID']; ?>" class="view-link">View Profile</a>
              </div>
            <?php endwhile; ?>
            <?php if ($total_caregivers > 10): ?>
              <div style="text-align:center; margin-top:10px;">
                <a href="#" style="color:#667eea;text-decoration:none">View all <?php echo $total_caregivers; ?> caregivers →</a>
              </div>
            <?php endif; ?>
          <?php endif; ?>
        </div>
        
        <div class="section-title">Visitors</div>
        <div class="user-list">
          <?php if ($visitors->num_rows === 0): ?>
            <p style="color:#666">No visitors found.</p>
          <?php else: ?>
            <?php while($vis = $visitors->fetch_assoc()): ?>
              <div class="user-item">
                <div>
                  <div class="user-name"><?php echo htmlspecialchars($vis['Name']); ?></div>
                  <div class="user-id">ID: <?php echo $vis['V_ID']; ?></div>
                </div>
                <a href="visitor.php?view=<?php echo $vis['V_ID']; ?>" class="view-link" style="background:#F57C00;">View Profile</a>
              </div>
            <?php endwhile; ?>
            <?php if ($total_visitors > 10): ?>
              <div style="text-align:center; margin-top:10px;">
                <a href="#" style="color:#667eea;text-decoration:none">View all <?php echo $total_visitors; ?> visitors →</a>
              </div>
            <?php endif; ?>
          <?php endif; ?>
        </div>
        
        <div class="section-title">Residents</div>
        <div class="user-list">
          <?php if ($residents->num_rows === 0): ?>
            <p style="color:#666">No residents found.</p>
          <?php else: ?>
            <?php while($res = $residents->fetch_assoc()): ?>
              <div class="user-item">
                <div>
                  <div class="user-name"><?php echo htmlspecialchars($res['Name']); ?></div>
                  <div class="user-id">ID: <?php echo $res['ID']; ?></div>
                </div>
                <a href="../residents/resident_profile.php?id=<?php echo $res['ID']; ?>" class="view-link" style="background:#2E7D32;">View Profile</a>
              </div>
            <?php endwhile; ?>
            <?php if ($total_residents > 10): ?>
              <div style="text-align:center; margin-top:10px;">
                <a href="#" style="color:#667eea;text-decoration:none">View all <?php echo $total_residents; ?> residents →</a>
              </div>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>
      
      <!-- Recent Appointments -->
      <div class="card" style="margin-top:20px">
        <div style="font-weight:1000;margin-bottom:12px">Recent Appointments</div>
        <?php
        $recent_apps = $conn->query("
            SELECT a.*, v.Name AS visitor_name, r.Name AS resident_name
            FROM Appointment a
            JOIN Visitor v ON a.Visitor_ID = v.V_ID
            JOIN Resident r ON a.Resident_ID = r.ID
            ORDER BY a.Created_At DESC
            LIMIT 5
        ");
        
        if ($recent_apps->num_rows === 0): ?>
          <p style="color:#666">No appointments found.</p>
        <?php else: ?>
          <?php while($app = $recent_apps->fetch_assoc()): ?>
            <div class="appointment-card appointment-<?php echo strtolower($app['Status']); ?>">
              <div style="display:flex;justify-content:space-between;align-items:start">
                <div>
                  <strong><?php echo htmlspecialchars($app['visitor_name']); ?></strong> → 
                  <strong><?php echo htmlspecialchars($app['resident_name']); ?></strong><br>
                  <small><?php echo $app['Requested_Date']; ?> at <?php echo $app['Requested_Time']; ?></small>
                </div>
                <span class="status-badge status-<?php echo strtolower($app['Status']); ?>">
                  <?php echo $app['Status']; ?>
                </span>
              </div>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
      
      <!-- Pending Appointment Requests -->
      <div class="card" style="margin-top:20px">
        <div style="font-weight:1000;margin-bottom:12px">Pending Appointment Requests</div>
        
        <?php if ($pending_appointments_list->num_rows === 0): ?>
          <p style="color:#666">No pending appointment requests.</p>
        <?php else: ?>
          <?php while($app = $pending_appointments_list->fetch_assoc()): ?>
            <div class="appointment-card appointment-pending">
              <div style="display:flex;justify-content:space-between;align-items:start">
                <div>
                  <strong><?php echo htmlspecialchars($app['visitor_name']); ?></strong> → 
                  <strong><?php echo htmlspecialchars($app['resident_name']); ?></strong><br>
                  <small><?php echo $app['Requested_Date']; ?> at <?php echo $app['Requested_Time']; ?></small>
                </div>
                <span class="status-badge status-pending">
                  Pending
                </span>
              </div>
              
              <div class="appointment-actions">
                <form method="post" action="../appointments/decision.php" style="display:inline;">
                  <input type="hidden" name="id" value="<?php echo $app['ID']; ?>">
                  <button type="submit" name="action" value="approve" class="action-btn approve-btn">
                    ✓ Approve
                  </button>
                </form>
                
                <button type="button" class="action-btn decline-btn decline-trigger" data-appointment-id="<?php echo $app['ID']; ?>">
                  ✗ Decline
                </button>
              </div>
              
              <div id="decline-box-<?php echo $app['ID']; ?>" class="decline-reason-box">
                <form method="post" action="../appointments/decision.php" class="decline-form">
                  <input type="hidden" name="id" value="<?php echo $app['ID']; ?>">
                  <input type="hidden" name="action" value="decline">
                  <textarea name="reason" class="reason-textarea" placeholder="Enter reason for declining this appointment..." required></textarea>
                  <div>
                    <button type="submit" class="reason-submit-btn">Submit Decline</button>
                    <button type="button" class="reason-cancel-btn" onclick="cancelDecline(<?php echo $app['ID']; ?>)">Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <script>
    // Handle decline button clicks
    document.querySelectorAll('.decline-trigger').forEach(button => {
      button.addEventListener('click', function() {
        const appointmentId = this.getAttribute('data-appointment-id');
        const declineBox = document.getElementById('decline-box-' + appointmentId);
        
        // Hide all other decline boxes
        document.querySelectorAll('.decline-reason-box').forEach(box => {
          box.style.display = 'none';
        });
        
        // Toggle this decline box
        if (declineBox.style.display === 'block') {
          declineBox.style.display = 'none';
        } else {
          declineBox.style.display = 'block';
          declineBox.querySelector('textarea').focus();
        }
      });
    });
    
    function cancelDecline(appointmentId) {
      const declineBox = document.getElementById('decline-box-' + appointmentId);
      declineBox.style.display = 'none';
      declineBox.querySelector('textarea').value = '';
    }
    
    // Handle form submission
    document.querySelectorAll('.decline-form').forEach(form => {
      form.addEventListener('submit', function(e) {
        const textarea = this.querySelector('textarea');
        if (textarea.value.trim() === '') {
          e.preventDefault();
          alert('Please enter a reason for declining.');
          textarea.focus();
        }
      });
    });
  </script>
</body>
</html>