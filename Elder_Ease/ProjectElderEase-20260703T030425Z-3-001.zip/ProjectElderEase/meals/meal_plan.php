<?php
session_start();
require_once "../connection.php";

$res_id = (int)$_GET['resident_id'];

// Get resident's food allergies
$allergies = $conn->query("
    SELECT a.Allergy_Name FROM Allergy a
    JOIN have_allergy ha ON a.ID = ha.Allergy_ID
    WHERE ha.R_ID = $res_id
");

$allergy_list = [];
while($a = $allergies->fetch_assoc()) {
    $allergy_list[] = strtolower($a['Allergy_Name']);
}

// Handle meal plan creation
$warning = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $breakfast = trim($_POST['breakfast'] ?? '');
    $lunch = trim($_POST['lunch'] ?? '');
    $dinner = trim($_POST['dinner'] ?? '');
    
    // Check each meal for allergies
    $meals_to_check = [$breakfast, $lunch, $dinner];
    $problematic_meals = [];
    
    foreach($meals_to_check as $meal) {
        foreach($allergy_list as $allergy) {
            if(stripos(strtolower($meal), $allergy) !== false) {
                $problematic_meals[] = "$meal (contains $allergy)";
            }
        }
    }
    
    if(!empty($problematic_meals)) {
        $warning = "⚠ Allergy Alert: " . implode(', ', $problematic_meals);
    } else {
        // Create meal plan
        $stmt = $conn->prepare("INSERT INTO Meal_Plan (Plan_Date, R_ID) VALUES (?, ?)");
        $stmt->bind_param("si", $_POST['plan_date'], $res_id);
        $stmt->execute();
        $meal_plan_id = $conn->insert_id;
        
        // Add meal types
        $stmt2 = $conn->prepare("INSERT INTO Type (M_Number, Breakfast, Lunch, Dinner) VALUES (?, ?, ?, ?)");
        $stmt2->bind_param("isss", $meal_plan_id, $breakfast, $lunch, $dinner);
        $stmt2->execute();
        
        $success = "Meal plan saved successfully!";
    }
}

// Get existing meal plans
$meal_plans = $conn->query("
    SELECT mp.*, t.* FROM Meal_Plan mp
    LEFT JOIN Type t ON mp.Number = t.M_Number
    WHERE mp.R_ID = $res_id
    ORDER BY mp.Plan_Date DESC
    LIMIT 5
");
?>

<div style="max-width:800px;margin:20px auto;">
    <h3 style="color:#333;">Meal Planning</h3>
    
    <!-- Allergy Warning -->
    <?php if(!empty($allergy_list)): ?>
    <div style="background:#fff3cd;padding:10px;border-radius:5px;margin:10px 0;">
        <strong>Food Allergies:</strong> 
        <?= implode(', ', array_map('ucfirst', $allergy_list)) ?>
    </div>
    <?php endif; ?>
    
    <?php if($warning): ?>
    <div style="background:#f8d7da;color:#721c24;padding:10px;border-radius:5px;margin:10px 0;">
        <?= $warning ?>
    </div>
    <?php endif; ?>
    
    <?php if(isset($success)): ?>
    <div style="background:#d4edda;color:#155724;padding:10px;border-radius:5px;margin:10px 0;">
        <?= $success ?>
    </div>
    <?php endif; ?>
    
    <!-- Create Meal Plan Form -->
    <form method="post" style="background:#f9f9f9;padding:20px;border-radius:8px;">
        <div style="margin:10px 0;">
            <label>Plan Date:</label>
            <input type="date" name="plan_date" required style="width:100%;padding:8px;">
        </div>
        
        <div style="margin:10px 0;">
            <label>Breakfast:</label>
            <input type="text" name="breakfast" placeholder="e.g., Oatmeal with fruits" style="width:100%;padding:8px;">
        </div>
        
        <div style="margin:10px 0;">
            <label>Lunch:</label>
            <input type="text" name="lunch" placeholder="e.g., Chicken soup" style="width:100%;padding:8px;">
        </div>
        
        <div style="margin:10px 0;">
            <label>Dinner:</label>
            <input type="text" name="dinner" placeholder="e.g., Grilled fish with vegetables" style="width:100%;padding:8px;">
        </div>
        
        <button type="submit" style="background:#28a745;color:white;padding:10px 20px;border:none;border-radius:4px;">
            Save Meal Plan
        </button>
    </form>
    
    <!-- Previous Meal Plans -->
    <h4 style="margin-top:30px;">Recent Meal Plans</h4>
    <?php while($plan = $meal_plans->fetch_assoc()): ?>
    <div style="border:1px solid #ddd;padding:15px;margin:10px 0;border-radius:5px;">
        <div style="color:#666;font-size:0.9em;">Date: <?= $plan['Plan_Date'] ?></div>
        <div style="margin:5px 0;"><strong>Breakfast:</strong> <?= htmlspecialchars($plan['Breakfast'] ?? 'Not set') ?></div>
        <div style="margin:5px 0;"><strong>Lunch:</strong> <?= htmlspecialchars($plan['Lunch'] ?? 'Not set') ?></div>
        <div style="margin:5px 0;"><strong>Dinner:</strong> <?= htmlspecialchars($plan['Dinner'] ?? 'Not set') ?></div>
    </div>
    <?php endwhile; ?>
</div>