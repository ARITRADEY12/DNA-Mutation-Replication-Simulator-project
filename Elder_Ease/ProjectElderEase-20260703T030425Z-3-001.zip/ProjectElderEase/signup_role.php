<?php
session_start();

$allowed = ['admin','caregiver','visitor'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'] ?? '';
    if (!in_array($role, $allowed, true)) {
        $_SESSION['error'] = "Please select a valid role.";
        header("Location: signup_role.php");
        exit();
    }
    $_SESSION['signup_role'] = $role;
    header("Location: signup.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Select Role - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:18px}
    .card{width:100%;max-width:520px;background:#fff;border-radius:16px;box-shadow:0 18px 40px rgba(0,0,0,.12);padding:28px}
    h1{font-size:26px;margin-bottom:6px}
    p{color:#555;margin-bottom:14px}
    .msg{padding:12px;border-radius:12px;margin-bottom:14px;border:1px solid}
    .err{background:#ffe9ea;border-color:#ffb2b7;color:#7a1020}
    .rolebox{border:2px solid #ececf4;border-radius:14px;padding:14px;margin:12px 0}
    .row{display:flex;gap:10px;align-items:flex-start;margin:10px 0}
    input[type=radio]{margin-top:3px}
    .title{font-weight:900;color:#222}
    .desc{color:#555;font-size:14px;margin-top:2px}
    .btn{margin-top:10px;width:100%;border:none;border-radius:12px;padding:12px;font-weight:900;background:#667eea;color:#fff;cursor:pointer}
    .btn:hover{filter:brightness(.96)}
    .links{margin-top:12px;text-align:center;color:#555}
    .links a{color:#667eea;text-decoration:none;font-weight:800}
    .links a:hover{text-decoration:underline}
  </style>
</head>
<body>
  <div class="card">
    <h1>Select your role</h1>

    <?php if (!empty($_SESSION['error'])): ?>
      <div class="msg err"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="post">
      <div class="rolebox">
        <div class="row">
          <input type="radio" name="role" value="admin" id="r_admin" required />
          <div>
            <div class="title"><label for="r_admin">Administrator</label></div>
          </div>
        </div>
        <div class="row">
          <input type="radio" name="role" value="caregiver" id="r_care" />
          <div>
            <div class="title"><label for="r_care">Caregiver</label></div>
          </div>
        </div>
        <div class="row">
          <input type="radio" name="role" value="visitor" id="r_vis" />
          <div>
            <div class="title"><label for="r_vis">Visitor</label></div>
          </div>
        </div>
      </div>

      <button class="btn" type="submit">Continue</button>
    </form>

    <div class="links">
      Already have an account? <a href="login.php">Login</a> · <a href="index.php">Home</a>
    </div>
  </div>
</body>
</html>

