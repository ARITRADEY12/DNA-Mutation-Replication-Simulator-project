<?php
session_start();

if (!empty($_SESSION['logged_in'])) {
    $role = $_SESSION['role'] ?? '';
    if ($role === 'admin') header("Location: dashboard/admin.php");
    elseif ($role === 'caregiver') header("Location: dashboard/caregiver.php");
    elseif ($role === 'visitor') header("Location: dashboard/visitor.php");
    else header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:18px}
    .card{width:100%;max-width:420px;background:#fff;border-radius:16px;box-shadow:0 18px 40px rgba(0,0,0,.12);padding:28px}
    h1{font-size:26px;margin-bottom:14px}
    .msg{padding:12px;border-radius:12px;margin-bottom:14px;border:1px solid}
    .err{background:#ffe9ea;border-color:#ffb2b7;color:#7a1020}
    label{display:block;font-weight:700;margin:12px 0 6px;color:#333}
    input{width:100%;padding:12px;border-radius:12px;border:2px solid #e7e7ef;font-size:15px}
    input:focus{outline:none;border-color:#667eea;box-shadow:0 0 0 3px rgba(102,126,234,.12)}
    .btn{margin-top:14px;width:100%;border:none;border-radius:12px;padding:12px;font-weight:800;background:#667eea;color:#fff;cursor:pointer}
    .btn:hover{filter:brightness(.96)}
    .links{margin-top:14px;text-align:center;color:#555}
    .links a{color:#667eea;text-decoration:none;font-weight:700}
    .links a:hover{text-decoration:underline}
  </style>
</head>
<body>
  <div class="card">
    <h1>Login</h1>

    <?php if (!empty($_SESSION['error'])): ?>
      <div class="msg err"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="post" action="auth.php">
      <label for="username">Username</label>
      <input id="username" name="username" type="text" required placeholder="Enter username" />

      <label for="password">Password</label>
      <input id="password" name="password" type="password" required placeholder="Enter password" />

      <button class="btn" type="submit">Login</button>
    </form>

    <div class="links">
      No account? <a href="signup_role.php">Signup</a> · <a href="index.php">Home</a>
    </div>
  </div>
</body>
</html>


