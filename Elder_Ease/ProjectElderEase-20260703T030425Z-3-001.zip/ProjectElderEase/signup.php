<?php
session_start();
require_once __DIR__ . "/connection.php";

if (empty($_SESSION['signup_role'])) {
    header("Location: signup_role.php");
    exit();
}

$role = $_SESSION['signup_role'];
$allowed = ['admin','caregiver','visitor'];
if (!in_array($role, $allowed, true)) {
    unset($_SESSION['signup_role']);
    header("Location: signup_role.php");
    exit();
}

$message = '';
$is_error = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $username = strtolower(trim($_POST['username'] ?? ''));
    $pass = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $extra = trim($_POST['extra'] ?? '');

    $errors = [];
    if ($name === '' || $username === '' || $pass === '' || $confirm === '') $errors[] = "All required fields must be filled.";
    if ($pass !== $confirm) $errors[] = "Passwords do not match.";
    if (strlen($pass) < 8) $errors[] = "Password must be at least 8 characters.";

    if ($role === 'caregiver') {
        if ($extra === '') $errors[] = "Email is required for caregiver.";
        elseif (!filter_var($extra, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    }
    if ($role === 'visitor') {
        if ($extra === '') $errors[] = "Contact is required for visitor.";
    }

    if (!$errors) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);

        $conn->begin_transaction();
        try {
            // User_login: (ID, Username, Password, Account_Status)
            $st = $conn->prepare("INSERT INTO User_login (Username, Password, Account_Status) VALUES (?, ?, 'active')");
            $st->bind_param("ss", $username, $hash);
            $st->execute();

            $user_id = $conn->insert_id;

            if ($role === 'admin') {
                $st2 = $conn->prepare("INSERT INTO Admin (A_ID, Name) VALUES (?, ?)");
                $st2->bind_param("is", $user_id, $name);
            } elseif ($role === 'caregiver') {
                $st2 = $conn->prepare("INSERT INTO CareGiver (C_ID, Name, Email) VALUES (?, ?, ?)");
                $st2->bind_param("iss", $user_id, $name, $extra);
            } else {
                $st2 = $conn->prepare("INSERT INTO Visitor (V_ID, Name, Contact) VALUES (?, ?, ?)");
                $st2->bind_param("iss", $user_id, $name, $extra);
            }
            $st2->execute();

            $conn->commit();

            unset($_SESSION['signup_role']);
            $_SESSION['user_id'] = (int)$user_id;
            $_SESSION['username'] = $username;
            $_SESSION['logged_in'] = true;
            $_SESSION['role'] = $role;

            if ($role === 'admin') header("Location: dashboard/admin.php");
            elseif ($role === 'caregiver') header("Location: dashboard/caregiver.php");
            else header("Location: dashboard/visitor.php");
            exit();

        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $is_error = true;

            // Duplicate username (unique constraint)
            if ((int)$e->getCode() === 1062) {
                $message = "Username already exists. Please choose another.";
            } else {
                $message = "Signup failed: " . $e->getMessage();
            }
        }
    } else {
        $is_error = true;
        $message = implode(" ", $errors);
    }
}

$extra_label = '';
$extra_placeholder = '';
if ($role === 'caregiver') { $extra_label = 'Email'; $extra_placeholder = 'rasna@gmail.com'; }
if ($role === 'visitor') { $extra_label = 'Contact'; $extra_placeholder = '01XXXXXXXXX'; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Signup - ElderEase</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,Tahoma,Verdana,sans-serif}
    body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:18px}
    .card{width:100%;max-width:520px;background:#fff;border-radius:16px;box-shadow:0 18px 40px rgba(0,0,0,.12);padding:28px}
    h1{font-size:26px;margin-bottom:6px}
    .sub{color:#555;margin-bottom:14px}
    .tag{display:inline-block;background:#eef1ff;color:#2b3ccf;border:1px solid #dfe4ff;padding:8px 10px;border-radius:999px;font-weight:800;font-size:12px;margin-bottom:12px}
    .msg{padding:12px;border-radius:12px;margin-bottom:14px;border:1px solid}
    .err{background:#ffe9ea;border-color:#ffb2b7;color:#7a1020}
    label{display:block;font-weight:800;margin:12px 0 6px;color:#333}
    input{width:100%;padding:12px;border-radius:12px;border:2px solid #e7e7ef;font-size:15px}
    input:focus{outline:none;border-color:#667eea;box-shadow:0 0 0 3px rgba(102,126,234,.12)}
    .btn{margin-top:14px;width:100%;border:none;border-radius:12px;padding:12px;font-weight:900;background:#667eea;color:#fff;cursor:pointer}
    .btn:hover{filter:brightness(.96)}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    @media(max-width:520px){.row{grid-template-columns:1fr}}
    .links{margin-top:12px;text-align:center;color:#555}
    .links a{color:#667eea;text-decoration:none;font-weight:800}
    .links a:hover{text-decoration:underline}
    .hint{font-size:13px;color:#666;margin-top:6px}
  </style>
</head>
<body>
  <div class="card">
    <div class="tag">Registering as: <?php echo htmlspecialchars(ucfirst($role)); ?></div>
    <h1>Create account</h1>

    <?php if ($message !== ''): ?>
      <div class="msg err"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <form method="post">
      <label for="name">Full Name</label>
      <input id="name" name="name" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" placeholder="Your name">

      <label for="username">Username</label>
      <input id="username" name="username" required value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" placeholder="Choose username">

      <div class="row">
        <div>
          <label for="password">Password</label>
          <input id="password" name="password" type="password" required placeholder="Min 8 chars">
          <div class="hint">We do not store plain passwords.</div>
        </div>
        <div>
          <label for="confirm_password">Confirm Password</label>
          <input id="confirm_password" name="confirm_password" type="password" required placeholder="Re-type password">
        </div>
      </div>

      <?php if ($role === 'caregiver' || $role === 'visitor'): ?>
        <label for="extra"><?php echo htmlspecialchars($extra_label); ?></label>
        <input id="extra" name="extra" required value="<?php echo htmlspecialchars($_POST['extra'] ?? ''); ?>" placeholder="<?php echo htmlspecialchars($extra_placeholder); ?>">
      <?php else: ?>
        <input type="hidden" name="extra" value="">
      <?php endif; ?>

      <button class="btn" type="submit">Create Account</button>
    </form>

    <div class="links">
      <a href="signup_role.php">Change role</a> · <a href="login.php">Login</a> · <a href="index.php">Home</a>
    </div>
  </div>
</body>
</html>

