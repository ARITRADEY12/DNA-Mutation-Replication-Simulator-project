<?php
session_start();
require_once "../connection.php";

if (!in_array($_SESSION['role'] ?? '', ['admin','caregiver'])) {
    die("Access denied");
}

$res_id = (int)$_GET['resident_id'];

// Add new allergy
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_allergy'])) {
    // First add to Allergy table
    $stmt = $conn->prepare("INSERT INTO Allergy (Allergy_Name, Severity) VALUES (?, ?)");
    $stmt->bind_param("ss", $_POST['name'], $_POST['severity']);
    $stmt->execute();
    $allergy_id = $conn->insert_id;
    
    // Then link to resident
    $stmt2 = $conn->prepare("INSERT INTO have_allergy (Allergy_ID, R_ID) VALUES (?, ?)");
    $stmt2->bind_param("ii", $allergy_id, $res_id);
    $stmt2->execute();
}

// Remove allergy
if (isset($_GET['remove'])) {
    $allergy_id = (int)$_GET['remove'];
    $conn->query("DELETE FROM have_allergy WHERE Allergy_ID = $allergy_id AND R_ID = $res_id");
}

// Get resident's allergies
$allergies = $conn->query("
    SELECT a.* FROM Allergy a
    JOIN have_allergy ha ON a.ID = ha.Allergy_ID
    WHERE ha.R_ID = $res_id
");
?>

<div style="max-width:600px;margin:20px auto;">
    <h3 style="color:#333;">Allergies Management</h3>
    
    <!-- Add Form -->
    <form method="post" style="background:#f8f9fa;padding:15px;border-radius:5px;margin-bottom:20px;">
        <h4>Add New Allergy</h4>
        
        <div style="margin:10px 0;">
            <label>Allergy Name:</label>
            <input type="text" name="name" required style="width:100%;padding:8px;">
        </div>
        
        <div style="margin:10px 0;">
            <label>Severity:</label>
            <select name="severity" style="width:100%;padding:8px;">
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
            </select>
        </div>
        
        <button type="submit" name="add_allergy" style="background:#17a2b8;color:white;padding:8px 15px;border:none;">
            Add Allergy
        </button>
    </form>
    
    <!-- Allergies List -->
    <h4>Current Allergies</h4>
    <?php if($allergies->num_rows > 0): ?>
        <?php while($a = $allergies->fetch_assoc()): 
            $severity_color = [
                'Low' => 'green',
                'Medium' => 'orange',
                'High' => 'red',
                'Critical' => 'darkred'
            ];
        ?>
        <div style="border-left:4px solid <?= $severity_color[$a['Severity']] ?? 'gray' ?>; 
                   padding:10px;margin:5px 0;background:white;">
            <strong><?= htmlspecialchars($a['Allergy_Name']) ?></strong>
            <span style="color:<?= $severity_color[$a['Severity']] ?? 'gray' ?>;margin-left:10px;">
                (<?= $a['Severity'] ?>)
            </span>
            <a href="?resident_id=<?= $res_id ?>&remove=<?= $a['ID'] ?>" 
               style="float:right;color:#dc3545;text-decoration:none;"
               onclick="return confirm('Remove this allergy?')">Remove</a>
        </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p style="color:#666;">No allergies recorded.</p>
    <?php endif; ?>
</div>