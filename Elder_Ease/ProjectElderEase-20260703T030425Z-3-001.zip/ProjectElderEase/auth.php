<?php
session_start();
require_once __DIR__ . "/connection.php";

unset($_SESSION['error']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Invalid request.";
    header("Location: login.php");
    exit();
}

$username = strtolower(trim($_POST['username'] ?? ''));
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    $_SESSION['error'] = "Username and password are required.";
    header("Location: login.php");
    exit();
}

// Match YOUR schema: User_login(ID, Username, Password, Account_Status)
$sql = "SELECT 
            ID AS id,
            Username AS username,
            Password AS password,
            Account_Status AS account_status
        FROM User_login
        WHERE LOWER(Username) = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || !password_verify($password, $user['password'])) {
    $_SESSION['error'] = "Invalid login credentials.";
    header("Location: login.php");
    exit();
}

if (($user['account_status'] ?? 'active') !== 'active') {
    $_SESSION['error'] = "Account is {$user['account_status']}.";
    header("Location: login.php");
    exit();
}

$_SESSION['user_id'] = (int)$user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['logged_in'] = true;

$id = $_SESSION['user_id'];

function existsRow(mysqli $conn, string $sql, int $id): bool {
    $s = $conn->prepare($sql);
    $s->bind_param("i", $id);
    $s->execute();
    return $s->get_result()->num_rows > 0;
}

// Match YOUR schema tables: Admin(A_ID), CareGiver(C_ID), Visitor(V_ID)
if (existsRow($conn, "SELECT 1 FROM Admin WHERE A_ID = ? LIMIT 1", $id)) {
    $_SESSION['role'] = 'admin';
    header("Location: dashboard/admin.php");
    exit();
}
if (existsRow($conn, "SELECT 1 FROM CareGiver WHERE C_ID = ? LIMIT 1", $id)) {
    $_SESSION['role'] = 'caregiver';
    header("Location: dashboard/caregiver.php");
    exit();
}
if (existsRow($conn, "SELECT 1 FROM Visitor WHERE V_ID = ? LIMIT 1", $id)) {
    $_SESSION['role'] = 'visitor';
    header("Location: dashboard/visitor.php");
    exit();
}

$_SESSION['error'] = "User role not found. Contact administrator.";
header("Location: login.php");
exit();
?>

